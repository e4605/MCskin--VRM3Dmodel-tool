"""Package this locally verified build without developer caches or test avatars."""
from pathlib import Path
from datetime import datetime
import json,shutil,zipfile,hashlib
from mcvrm import __version__

ROOT=Path(__file__).resolve().parent
DOWNLOADS=Path.home()/'Downloads'
name='MC皮肤转VRM工具_v'+__version__
dest=DOWNLOADS/name
if dest.exists():dest=DOWNLOADS/(name+'_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
assert dest.parent.resolve()==DOWNLOADS.resolve() and not dest.exists()
shutil.copytree(ROOT/'dist'/__version__/'MCSkinVRM',dest)
for file in ['README.md','CHANGELOG.md','使用说明.md','研究与兼容性.md','THIRD_PARTY_NOTICES.md','LICENSE']:
    shutil.copy2(ROOT/file,dest/file)
verification=dest/'verification';verification.mkdir()
if (ROOT/'resources/compatibility.json').exists():shutil.copy2(ROOT/'resources/compatibility.json',verification/'compatibility.json')
smoke=ROOT/'gui_smoke_result.json'
if smoke.exists():
    flow=json.loads(smoke.read_text(encoding='utf-8'));gui_job=Path(flow['output'])
    report=json.loads((gui_job/'report.json').read_text(encoding='utf-8'))
    assert report['texture_pixels_verified'] and report['roundtrip_import'] and report['finger_mapping_check']
    assert report['converter_version']==__version__
    (verification/'qwq_gui_export.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    shutil.copy2(gui_job/'preview.png',verification/'qwq_preview.png')
    clean_flow={k:v for k,v in flow.items() if 'output' not in k}
    (verification/'gui_flow.json').write_text(json.dumps(clean_flow,indent=2),encoding='utf-8')

def zip_files(path,files):
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for src,arc in files:z.write(src,arc)
    with zipfile.ZipFile(path) as z:assert z.testzip() is None

portable=dest.with_name(dest.name+'_Windows.zip')
zip_files(portable,[(f,'MCSkinVRM/'+f.relative_to(dest).as_posix()) for f in sorted(dest.rglob('*')) if f.is_file()])
source=dest.with_name(dest.name+'_源码.zip')
files=[]
for filename in ['app.py','cli.py','build_windows.py','package_release.py','requirements.txt','requirements-build.txt',
                 'README.md','CHANGELOG.md','使用说明.md','研究与兼容性.md','THIRD_PARTY_NOTICES.md','LICENSE']:
    files.append((ROOT/filename,'MCSkinVRM_Source/'+filename))
for dirname in ['mcvrm','resources','tests','licenses']:
    for file in sorted((ROOT/dirname).rglob('*')):
        if file.is_file() and '__pycache__' not in file.parts and file.suffix.lower() not in ['.pyc','.pyo']:
            files.append((file,'MCSkinVRM_Source/'+file.relative_to(ROOT).as_posix()))
zip_files(source,files)
data={'folder':str(dest),'executable':str(dest/'MCSkinVRM.exe'),'portable_zip':str(portable),'source_zip':str(source),
      'sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in [portable,source]}}
(ROOT/'release_paths.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
(dest/'SHA256.json').write_text(json.dumps(data['sha256'],ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(data,ensure_ascii=True,indent=2))
