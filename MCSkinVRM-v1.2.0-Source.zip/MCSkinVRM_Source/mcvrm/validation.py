"""Independent GLB / VRM0 and consumer-specific skeleton checks."""
from pathlib import Path
import json,struct,math,hashlib,io

REQUIRED={'hips','spine','chest','neck','head',*(side+bone for side in ['left','right'] for bone in ['Shoulder','UpperArm','LowerArm','Hand','UpperLeg','LowerLeg','Foot','Toes'])}
FINGERS={side+finger+segment for side in ['left','right'] for finger in ['Thumb','Index','Middle','Ring','Little'] for segment in ['Proximal','Intermediate','Distal']}

def parse(path):
    data=Path(path).read_bytes()
    if len(data)<20 or struct.unpack_from('<4sII',data)!=(b'glTF',2,len(data)):raise ValueError('GLB 文件头无效或文件未完整写入。')
    offset=12;chunks={}
    while offset<len(data):
        if offset+8>len(data):raise ValueError('GLB chunk 被截断。')
        n,kind=struct.unpack_from('<II',data,offset);offset+=8
        if n%4 or offset+n>len(data):raise ValueError('GLB chunk 长度无效。')
        chunks[kind]=data[offset:offset+n];offset+=n
    return json.loads(chunks[0x4e4f534a]),chunks[0x004e4942]

def accessor(doc,blob,index):
    a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']]
    fmt,size={5120:('b',1),5121:('B',1),5122:('h',2),5123:('H',2),5125:('I',4),5126:('f',4)}[a['componentType']]
    count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
    start=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size*count)
    if a['count'] and start+(a['count']-1)*stride+size*count>v.get('byteOffset',0)+v['byteLength']:raise ValueError('Accessor 超出 bufferView。')
    return [struct.unpack_from('<'+fmt*count,blob,start+i*stride) for i in range(a['count'])]

def inspect_vrm(path,texture=None,eyes=None):
    doc,blob=parse(path)
    ext=doc['extensions']['VRM'];nodes=doc['nodes']
    mapping={b['bone']:b['node'] for b in ext['humanoid']['humanBones']}
    if not REQUIRED|FINGERS<=mapping.keys():raise ValueError('缺少人形骨骼或双手手指映射。')
    if len(set(mapping.values()))!=len(mapping):raise ValueError('多个骨骼映射到同一个节点。')
    for side in ['left','right']:
        for finger in ['Thumb','Index','Middle','Ring','Little']:
            chain=[side+finger+s for s in ['Proximal','Intermediate','Distal']]
            parent=mapping[side+'Hand']
            for name in chain:
                child=mapping[name]
                if child not in nodes[parent].get('children',[]):raise ValueError('手指骨骼层级错误：'+name)
                parent=child
            if not nodes[parent].get('children'):raise ValueError('手指缺少终端节点。')
    groups={g['presetName']:g for g in ext['blendShapeMaster']['blendShapeGroups']}
    for key in ['a','i','u','e','o']:
        if groups.get(key,{}).get('binds') or groups.get(key,{}).get('materialValues'):raise ValueError('检测到不应存在的口型绑定。')
    if eyes and not all(groups.get(k,{}).get('binds') for k in ['blink','blink_l','blink_r']):raise ValueError('眨眼绑定丢失。')
    vertices=triangles=0;shapes=set();weight_error=0
    for mesh in doc['meshes']:
        names=mesh.get('extras',{}).get('targetNames',[]);shapes.update(names)
        if {'A','I','U','E','O','Mouth','JawOpen'}&set(names):raise ValueError('检测到口型形态键。')
        for p in mesh['primitives']:
            attrs=p['attributes'];positions=accessor(doc,blob,attrs['POSITION']);vertices+=len(positions)
            if not all(math.isfinite(c) for point in positions for c in point):raise ValueError('顶点坐标包含无效值。')
            indices=accessor(doc,blob,p['indices']);triangles+=len(indices)//3
            if any(v[0]>=len(positions) for v in indices):raise ValueError('三角形索引越界。')
            for w in accessor(doc,blob,attrs['WEIGHTS_0']):
                if not all(math.isfinite(n) and n>=0 for n in w):raise ValueError('蒙皮权重无效。')
                weight_error=max(weight_error,abs(sum(w)-1))
    if weight_error>1e-5:raise ValueError('蒙皮权重未归一化。')
    for mat in doc['materials']:
        tid=mat.get('pbrMetallicRoughness',{}).get('baseColorTexture',{}).get('index')
        if tid is not None:
            sampler=doc['samplers'][doc['textures'][tid]['sampler']]
            if sampler.get('magFilter')!=9728 or sampler.get('minFilter')!=9728:raise ValueError('像素纹理没有使用最近邻采样。')
    pixel_verified=False
    if texture:
        from PIL import Image
        with Image.open(texture) as im:target=im.convert('RGBA')
        for image in doc['images']:
            v=doc['bufferViews'][image['bufferView']];start=v.get('byteOffset',0)
            embedded=Image.open(io.BytesIO(blob[start:start+v['byteLength']])).convert('RGBA')
            if embedded.size==target.size and embedded.tobytes()==target.tobytes():pixel_verified=True
        if not pixel_verified:raise ValueError('内嵌贴图与准备后的皮肤像素不一致。')
    return {'vrm_version':ext['specVersion'],'humanoid_mappings':len(mapping),'finger_mapping_check':True,
            'vertices':vertices,'triangles':triangles,'mesh_count':len(doc['meshes']),'shape_keys':sorted(shapes),
            'no_added_mouth':True,'texture_pixels_verified':pixel_verified,'max_weight_error':weight_error,
            'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),
            'target_application_test':'未执行面捕软件实机加载或推流；此项是结构兼容检查。'}
