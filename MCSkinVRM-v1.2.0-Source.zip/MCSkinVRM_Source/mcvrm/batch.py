"""Sequential, cancellable batch conversion with an explicit result manifest."""
from pathlib import Path
from datetime import datetime
import json,os,uuid
from .blender import inspect_blender
from .jobs import prepare_with_fallback,run,recommended_output_dirs,OutputDirectoryError
from .options import normalize_options

def create_batch_folder(output_root):
    if not str(output_root).strip():raise ValueError('请选择输出目录。')
    roots=[Path(output_root).expanduser().resolve(),*recommended_output_dirs()]
    name='Batch_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]
    seen=set();last=None
    for root in roots:
        root=root.resolve();key=os.path.normcase(str(root))
        if key in seen:continue
        seen.add(key);folder=root/name
        try:
            folder.mkdir(parents=True,exist_ok=False)
            (folder/'batch_results.json').write_text('{"state":"running"}',encoding='utf-8')
            return folder
        except (PermissionError,NotADirectoryError) as error:last=error
    raise OutputDirectoryError(roots[0],last)

def convert_batch(blender,paths,output_root,model='auto',height=1.8,author='Skin owner',
                  opaque_fix=True,preview=True,options=None,cancel=None,
                  on_progress=lambda p,m:None,on_process=lambda p:None,on_folder=lambda p:None):
    info=inspect_blender(blender);options=normalize_options(options)
    selected=[];seen=set()
    for value in paths:
        path=Path(value).expanduser().resolve();key=os.path.normcase(str(path))
        if key not in seen:seen.add(key);selected.append(path)
    if not selected:raise ValueError('请至少选择一张皮肤。')
    if len(selected)>200:raise ValueError('每批最多选择 200 张皮肤，请分批转换。')
    if cancel is not None and cancel.is_set():raise InterruptedError('批量转换已取消。')
    folder=create_batch_folder(output_root);on_folder(folder)
    summary={'version':1,'state':'running','blender':info['label'],'total':len(selected),
             'succeeded':0,'failed':0,'cancelled':False,'items':[]}
    def save():
        temp=folder/'batch_results.tmp'
        temp.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
        temp.replace(folder/'batch_results.json')
    for index,path in enumerate(selected):
        if cancel is not None and cancel.is_set():summary['cancelled']=True;break
        item={'input':str(path)}
        try:
            out,job,notice=prepare_with_fallback(path,folder,name=path.stem,model=model,height=height,
                 author=author,opaque_fix=opaque_fix,preview=preview,eyes=None,options=options)
            item['output']=str(out)
            if notice:item['notice']=notice
            run(blender,out,lambda p,m:on_progress((index+p/100)/len(selected)*100,f'[{index+1}/{len(selected)}] {path.name} · {m}'),cancel,on_process)
            item['status']='success';summary['succeeded']+=1
        except (InterruptedError,KeyboardInterrupt):
            item['status']='cancelled';summary['cancelled']=True;summary['items'].append(item);save();break
        except Exception as error:
            item.update({'status':'error','error':str(error)});summary['failed']+=1
        summary['items'].append(item);save()
        on_progress((index+1)/len(selected)*100,f"已处理 {index+1}/{len(selected)} · 成功 {summary['succeeded']} · 失败 {summary['failed']}")
    summary['not_started']=len(selected)-len(summary['items'])
    summary['state']='cancelled' if summary['cancelled'] else 'complete';save()
    return folder,summary
