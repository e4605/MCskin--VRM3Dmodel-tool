"""Skin validation and normalization. Coordinates use the standard 64px atlas."""
from pathlib import Path
from PIL import Image, ImageOps, UnidentifiedImageError

PARTS = [('head',(0,0),(32,0),8,8,8),('body',(16,16),(16,32),8,12,4),
         ('rightArm',(40,16),(40,32),None,12,4),('leftArm',(32,48),(48,48),None,12,4),
         ('rightLeg',(0,16),(0,32),4,12,4),('leftLeg',(16,48),(0,48),4,12,4)]

def rectangles(origin,w,h,d):
    u,v=origin
    return [(u+d,v,w,d),(u+d+w,v,w,d),(u,v+d,d,h),(u+d,v+d,w,h),
            (u+d+w,v+d,d,h),(u+2*d+w,v+d,w,h)]

def infer_model(image,legacy=False):
    if legacy:return 'classic'
    k=image.width//64
    boxes=[(50,16,52,20),(54,20,56,32),(42,48,44,52),(46,52,48,64)]
    blocks=[image.crop(tuple(n*k for n in r)) for r in boxes]
    # PNG does not encode arm type. Alpha in unused strips is the strongest hint.
    if any(p.getchannel('A').getextrema()[0]<255 for p in blocks):return 'slim'
    for color in [(0,0,0,255),(255,255,255,255)]:
        if all(all(p.getpixel((x,y))==color for y in range(p.height) for x in range(p.width)) for p in blocks):return 'slim'
    return 'classic'

def read_skin(path,model='auto',opaque_fix=True):
    path=Path(path)
    try:src=Image.open(path)
    except (UnidentifiedImageError,OSError) as error:
        raise ValueError('无法读取皮肤 PNG，请检查文件是否完整、是否可访问。') from error
    with src:
        if src.format!='PNG':raise ValueError('请选择 PNG 格式的 Minecraft 皮肤。')
        if src.width not in (64,128,256) or src.height not in (src.width,src.width//2):
            raise ValueError('支持 64/128/256 像素宽的方形皮肤，或对应的旧版 2:1 皮肤。')
        if getattr(src,'n_frames',1)!=1:raise ValueError('不支持动画 PNG，请使用单张皮肤。')
        im=src.convert('RGBA')
    legacy=im.height*2==im.width;k=im.width//64
    notes=[]
    fully_opaque=im.getchannel('A').getextrema()==(255,255)
    if legacy:
        square=Image.new('RGBA',(im.width,im.width));square.paste(im,(0,0));im=square
        # Mirror opposite limb faces; copying the whole atlas would swap sides.
        mirrors=[(4,16,4,4,20,48),(8,16,4,4,24,48),(0,20,4,12,24,52),
                 (4,20,4,12,20,52),(8,20,4,12,16,52),(12,20,4,12,28,52),
                 (44,16,4,4,36,48),(48,16,4,4,40,48),(40,20,4,12,40,52),
                 (44,20,4,12,36,52),(48,20,4,12,32,52),(52,20,4,12,44,52)]
        for sx,sy,w,h,dx,dy in mirrors:
            patch=im.crop((sx*k,sy*k,(sx+w)*k,(sy+h)*k))
            im.paste(ImageOps.mirror(patch),(dx*k,dy*k))
        notes.append('旧版皮肤已镜像补全左臂和左腿。')
    selected=infer_model(im,legacy) if model=='auto' else model
    if selected not in ('classic','slim'):raise ValueError('手臂类型必须为 auto、classic 或 slim。')
    if legacy and selected=='slim':raise ValueError('旧版 2:1 皮肤使用普通手臂，不能直接指定细手臂。')
    aw=3 if selected=='slim' else 4
    if fully_opaque and opaque_fix:
        for _,_,overlay,w,h,d in PARTS:
            for x,y,rw,rh in rectangles(overlay,aw if w is None else w,h,d):
                im.paste((0,0,0,0),(x*k,y*k,(x+rw)*k,(y+rh)*k))
        notes.append('检测到不透明背景：已按 MC 皮肤惯例移除第二层；可取消此选项以保留。')
    elif fully_opaque:notes.append('整张图片不透明，已按你的选择保留全部第二层。')
    # The base layer is opaque in Minecraft; only outer layers carry alpha.
    for _,base,_,w,h,d in PARTS:
        for x,y,rw,rh in rectangles(base,aw if w is None else w,h,d):
            patch=im.crop((x*k,y*k,(x+rw)*k,(y+rh)*k));patch.putalpha(255)
            im.paste(patch,(x*k,y*k))
    if model=='auto':notes.append('手臂自动识别仅为推断；外观异常时请手动切换。')
    return im,{'model':selected,'scale':k,'legacy':legacy,'size':[im.width,im.height],'notes':notes}

def validate_eyes(profile):
    if profile is None:return None
    if not isinstance(profile,dict):raise ValueError('眼睛配置应为包含 left 和 right 的 JSON 对象。')
    if not profile:return None
    result={}
    for side in ['left','right']:
        cells=profile.get(side,[])
        if not cells or len(cells)>24:raise ValueError('每只眼睛请选择 1—24 个脸部像素。')
        points=set()
        for cell in cells:
            if not isinstance(cell,(list,tuple)) or len(cell)!=2 or any(type(v) is not int or not 0<=v<8 for v in cell):
                raise ValueError('眼睛像素坐标必须为 0—7 的整数。')
            points.add(tuple(cell))
        result[side]=sorted(points)
    if set(result['left'])&set(result['right']):raise ValueError('左右眼不能选择同一个像素。')
    for side in ['left','right']:
        p=profile.get(side+'_lid')
        if p is not None and (not isinstance(p,(list,tuple)) or len(p)!=2 or any(type(v) is not int or not 0<=v<8 for v in p)):
            raise ValueError('闭眼底色取样点无效。')
        if p is not None and tuple(p) in set(result['left'])|set(result['right']):
            raise ValueError('闭眼底色应取自眼睛之外的皮肤或头发像素。')
        result[side+'_lid']=p
    return result
