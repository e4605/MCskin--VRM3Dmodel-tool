"""Advanced settings stay in a separate dialog so the main window stays simple."""
from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
import json,threading,queue,math
from .options import DEFAULTS,normalize_options
from .blender import find_installations,inspect_blender,SUPPORTED_TEXT

BG='#0c1423';PANEL='#162338';TEXT='#edf3fc';MUTED='#a4b6cc'
QUALITY={'快速 · 512 × 640':'fast','标准 · 800 × 1000':'standard','高清 · 1024 × 1280':'high'}

class AdvancedDialog(tk.Toplevel):
    def __init__(self,parent):
        super().__init__(parent);self.parent=parent;self.title('高级选项');self.configure(bg=BG)
        self.resizable(False,False);self.protocol('WM_DELETE_WINDOW',self.close)
        self.paths=[];self.queue=queue.Queue();self.closed=False;self.timer=None
        opts=normalize_options(parent.advanced_options)
        self.author=tk.StringVar(value=parent.author.get());self.height=tk.StringVar(value=parent.height.get())
        self.opaque=tk.BooleanVar(value=parent.opaque.get());self.save_blend=tk.BooleanVar(value=opts['save_blend'])
        self.views=tk.BooleanVar(value=opts['preview_views']);self.demo=tk.BooleanVar(value=opts['demo_animation'])
        self.quality=tk.StringVar(value=next(label for label,key in QUALITY.items() if key==opts['preview_quality']))
        self.timeout=tk.StringVar(value=str(opts['timeout_seconds']/60).removesuffix('.0'))
        tk.Label(self,text='高级选项',bg=BG,fg=TEXT,font=('Microsoft YaHei UI',16,'bold')).pack(anchor='w',padx=22,pady=(18,6))
        tk.Label(self,text='默认设置即可完成普通转换；这些功能按需开启。',bg=BG,fg=MUTED).pack(anchor='w',padx=22,pady=(0,12))
        tabs=ttk.Notebook(self);tabs.pack(fill='both',padx=22,pady=4)
        export=ttk.Frame(tabs,padding=18);batch=ttk.Frame(tabs,padding=18);diagnostic=ttk.Frame(tabs,padding=18)
        tabs.add(export,text='导出与预览');tabs.add(batch,text='批量转换');tabs.add(diagnostic,text='Blender 检测')
        export.columnconfigure(1,weight=1)
        for row,label,var in [(0,'作者信息',self.author),(1,'身高（米）',self.height)]:
            ttk.Label(export,text=label).grid(row=row,column=0,sticky='w',padx=(0,16),pady=6)
            ttk.Entry(export,textvariable=var,width=40).grid(row=row,column=1,sticky='ew',pady=6)
        ttk.Checkbutton(export,text='全不透明皮肤：自动移除第二层背景',variable=self.opaque).grid(row=2,column=0,columnspan=2,sticky='w',pady=8)
        ttk.Checkbutton(export,text='同时保存可编辑 Blender 工程',variable=self.save_blend,command=self.blend_changed).grid(row=3,column=0,columnspan=2,sticky='w',pady=8)
        ttk.Label(export,text='预览质量').grid(row=4,column=0,sticky='w',pady=6)
        ttk.Combobox(export,textvariable=self.quality,values=list(QUALITY),state='readonly',width=36).grid(row=4,column=1,sticky='ew',pady=6)
        ttk.Checkbutton(export,text='额外输出正面、侧面、背面预览图',variable=self.views).grid(row=5,column=0,columnspan=2,sticky='w',pady=8)
        ttk.Checkbutton(export,text='生成挥手演示（保存在 Blender 工程中）',variable=self.demo,command=self.demo_changed).grid(row=6,column=0,columnspan=2,sticky='w',pady=8)
        ttk.Label(export,text='三视图会自动启用预览；挥手使用手臂与手腕骨骼，不会新增嘴巴。\nVRM 文件保持标准静止姿态，演示动作只保存在工程中。',style='Muted.TLabel',wraplength=550).grid(row=7,column=0,columnspan=2,sticky='w',pady=8)
        ttk.Label(export,text='每个模型超时（分钟）').grid(row=8,column=0,sticky='w',pady=6)
        ttk.Spinbox(export,textvariable=self.timeout,from_=.5,to=120,increment=.5,width=12).grid(row=8,column=1,sticky='w')
        ttk.Label(export,text='超时或取消只停止本次转换启动的 Blender，不影响其他工程。',style='Muted.TLabel',wraplength=550).grid(row=9,column=0,columnspan=2,sticky='w',pady=8)
        ttk.Label(batch,text='选择多张 PNG，逐个生成独立模型和结果报告。\n不同皮肤眼睛位置不同，批量模式默认保留静态脸。',wraplength=550).pack(anchor='w',pady=(0,10))
        self.files=tk.Listbox(batch,width=68,height=9,bg='#101b2d',fg=TEXT,selectbackground='#335271',borderwidth=0);self.files.pack(fill='x')
        actions=ttk.Frame(batch);actions.pack(fill='x',pady=10)
        for label,fn in [('添加皮肤…',self.add_files),('添加文件夹…',self.add_folder),('清空',self.clear_files)]:ttk.Button(actions,text=label,command=fn).pack(side='left',padx=(0,8))
        self.batch_model=tk.StringVar(value='自动识别（逐张判断）')
        ttk.Label(batch,text='批量手臂类型').pack(anchor='w',pady=(8,4))
        ttk.Combobox(batch,textvariable=self.batch_model,values=['自动识别（逐张判断）','普通手臂（Steve）','细手臂（Alex）'],state='readonly').pack(fill='x')
        ttk.Label(batch,text='输出到主界面所选目录。单张失败会记录原因，继续处理其他皮肤；支持取消。',style='Muted.TLabel',wraplength=550).pack(anchor='w',pady=12)
        ttk.Button(batch,text='按这些设置开始批量转换',style='Accent.TButton',command=self.start_batch).pack(fill='x',pady=8)
        ttk.Label(diagnostic,text=f'支持范围：{SUPPORTED_TEXT}\n会读取程序实际版本，避免把其他版本或快捷方式误当成 Blender。',wraplength=550).pack(anchor='w',pady=(0,12))
        self.tree=ttk.Treeview(diagnostic,columns=('version','support','path'),show='headings',height=9)
        for key,label,width in [('version','版本',135),('support','状态',110),('path','程序路径',300)]:
            self.tree.heading(key,text=label);self.tree.column(key,width=width,stretch=False)
        self.tree.pack(fill='x');self.installations=[]
        self.scan_label=ttk.Label(diagnostic,text='点击扫描，或检查主界面已选程序。',style='Muted.TLabel');self.scan_label.pack(anchor='w',pady=10)
        tools=ttk.Frame(diagnostic);tools.pack(fill='x')
        self.scan_btn=ttk.Button(tools,text='扫描本机 Blender',command=self.scan);self.scan_btn.pack(side='left',padx=(0,8))
        ttk.Button(tools,text='检查已选程序',command=self.check_current).pack(side='left',padx=(0,8))
        ttk.Button(tools,text='使用列表中选中的版本',command=self.select_installation).pack(side='left')
        buttons=ttk.Frame(self,padding=18);buttons.pack(fill='x')
        ttk.Button(buttons,text='恢复默认',command=self.reset).pack(side='left')
        ttk.Button(buttons,text='应用设置',style='Accent.TButton',command=self.apply).pack(side='right')
        ttk.Button(buttons,text='关闭',command=self.close).pack(side='right',padx=10)
        self.transient(parent);self.grab_set();self.timer=self.after(150,self.poll)
    def demo_changed(self):
        if self.demo.get():self.save_blend.set(True)
    def blend_changed(self):
        if not self.save_blend.get():self.demo.set(False)
    def values(self):
        height=float(self.height.get())
        if not math.isfinite(height) or not .5<=height<=3:raise ValueError('身高应为 0.5—3 米。')
        opts=normalize_options({'save_blend':self.save_blend.get(),'preview_quality':QUALITY[self.quality.get()],
             'preview_views':self.views.get(),'demo_animation':self.demo.get(),'timeout_seconds':float(self.timeout.get())*60})
        return height,opts
    def apply(self,close=True):
        try:height,opts=self.values()
        except (ValueError,KeyError):messagebox.showerror('高级选项','请检查身高、预览质量和超时时间。身高为 0.5—3 米，超时为 0.5—120 分钟。',parent=self);return False
        self.parent.height.set(str(height));self.parent.author.set(self.author.get().strip() or 'Skin owner')
        self.parent.opaque.set(self.opaque.get());self.parent.advanced_options=opts
        if opts['preview_views']:self.parent.preview.set(True)
        self.parent.refresh_skin();self.parent.update_advanced_label();self.parent.save_settings()
        if close:self.close()
        return True
    def reset(self):
        self.height.set('1.8');self.author.set('Skin owner');self.opaque.set(True);self.save_blend.set(True)
        self.views.set(False);self.demo.set(False);self.quality.set(next(iter(QUALITY)));self.timeout.set('15')
    def add_paths(self,values):
        for value in values:
            p=Path(value).resolve()
            if p not in self.paths:self.paths.append(p);self.files.insert('end',p.name)
    def add_files(self):self.add_paths(filedialog.askopenfilenames(parent=self,title='选择多张 MC 皮肤',filetypes=[('皮肤 PNG','*.png')]))
    def add_folder(self):
        folder=filedialog.askdirectory(parent=self,title='选择包含皮肤的文件夹')
        if folder:self.add_paths(sorted(p for p in Path(folder).iterdir() if p.is_file() and p.suffix.lower()=='.png'))
    def clear_files(self):self.paths.clear();self.files.delete(0,'end')
    def start_batch(self):
        if not self.paths:messagebox.showinfo('批量转换','请先添加皮肤 PNG。',parent=self);return
        if len(self.paths)>200:messagebox.showerror('批量转换','每批最多 200 张皮肤，请减少选择。',parent=self);return
        if not self.apply(close=False):return
        model={'自动识别（逐张判断）':'auto','普通手臂（Steve）':'classic','细手臂（Alex）':'slim'}[self.batch_model.get()]
        self.parent.start_batch(list(self.paths),model);self.close()
    def scan(self):
        self.scan_btn.configure(state='disabled');self.scan_label.configure(text='正在读取 Blender 版本…')
        current=self.parent.blender.get()
        def work():
            try:
                items=find_installations()
                if current and not any(item['path']==str(Path(current).resolve()) for item in items):
                    try:items.insert(0,inspect_blender(current,False))
                    except (OSError,ValueError):pass
                self.queue.put(('scan',items))
            except Exception as error:self.queue.put(('error',str(error)))
        threading.Thread(target=work,daemon=True).start()
    def check_current(self):
        try:info=inspect_blender(self.parent.blender.get(),False)
        except (ValueError,OSError) as error:messagebox.showerror('Blender 检测',str(error),parent=self);return
        messagebox.showinfo('Blender 检测',info['label']+'\n'+('在支持范围内' if info['supported'] else '不在支持范围内')+'\n\n'+info['path'],parent=self)
    def select_installation(self):
        selected=self.tree.selection()
        if not selected:return
        info=self.installations[int(selected[0])]
        if not info['supported']:messagebox.showerror('Blender 版本',f'请选择 {SUPPORTED_TEXT}。',parent=self);return
        self.parent.blender.set(info['path']);self.scan_label.configure(text='已切换主界面的 Blender 程序：'+info['label'])
    def poll(self):
        if self.closed:return
        try:
            while True:
                kind,value=self.queue.get_nowait();self.scan_btn.configure(state='normal')
                if kind=='scan':
                    self.installations=value
                    for item in self.tree.get_children():self.tree.delete(item)
                    for i,info in enumerate(value):self.tree.insert('', 'end',iid=str(i),values=(info['label'],'支持范围内' if info['supported'] else '不支持',info['path']))
                    self.scan_label.configure(text=f'找到 {len(value)} 个程序。选择一行后可切换版本。')
                else:self.scan_label.configure(text=value)
        except queue.Empty:pass
        self.timer=self.after(150,self.poll)
    def close(self):
        self.closed=True
        if self.timer:
            try:self.after_cancel(self.timer)
            except tk.TclError:pass
        self.destroy()
