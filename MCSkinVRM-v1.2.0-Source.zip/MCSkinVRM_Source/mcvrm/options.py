"""Validated advanced settings. Defaults preserve the ordinary conversion."""
import math

DEFAULTS={'save_blend':True,'preview_quality':'fast','preview_views':False,
          'demo_animation':False,'timeout_seconds':900}
PREVIEW_PROFILES={'fast':(512,640,16),'standard':(800,1000,32),'high':(1024,1280,64)}

def normalize_options(value=None):
    if value is not None and not isinstance(value,dict):raise ValueError('高级选项格式无效。')
    result=DEFAULTS.copy()
    if value:result.update({k:v for k,v in value.items() if k in DEFAULTS})
    for key in ['save_blend','preview_views','demo_animation']:
        if type(result[key]) is not bool:raise ValueError('高级选项中的开关必须为布尔值。')
    if not isinstance(result['preview_quality'],str) or result['preview_quality'] not in PREVIEW_PROFILES:raise ValueError('预览质量应为 fast、standard 或 high。')
    timeout=result['timeout_seconds']
    if isinstance(timeout,bool) or not isinstance(timeout,(int,float)) or not math.isfinite(timeout) or not 30<=timeout<=7200:
        raise ValueError('单个转换的超时时间应为 30 秒到 120 分钟。')
    if result['demo_animation'] and not result['save_blend']:
        raise ValueError('挥手演示需要同时保存 Blender 工程。')
    return result
