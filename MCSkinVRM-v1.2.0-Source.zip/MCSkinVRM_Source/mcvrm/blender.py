"""Discover and inspect external Blender executables without changing preferences."""
from pathlib import Path
from functools import lru_cache
import os,re,shutil,subprocess,sys

MIN_VERSION=(4,2,0)
MAX_VERSION=(5,3,0)
SUPPORTED_TEXT='Blender 4.2—5.2'

def process_environment():
    env=os.environ.copy()
    env['PYTHONIOENCODING']='utf-8'
    if os.name=='nt' and getattr(sys,'frozen',False):
        root=str(Path(sys._MEIPASS).resolve()).lower()
        env['PATH']=os.pathsep.join(p for p in env.get('PATH','').split(os.pathsep)
                                   if p and not str(Path(p).resolve()).lower().startswith(root))
    return env

def spawn(args,**kwargs):
    """Avoid leaking the frozen app's DLL directory into external applications."""
    frozen=os.name=='nt' and getattr(sys,'frozen',False)
    if frozen:
        import ctypes
        ctypes.windll.kernel32.SetDllDirectoryW(None)
    try:
        if os.name=='nt':kwargs.setdefault('creationflags',subprocess.CREATE_NO_WINDOW)
        kwargs.setdefault('env',process_environment())
        return subprocess.Popen(args,**kwargs)
    finally:
        if frozen:ctypes.windll.kernel32.SetDllDirectoryW(sys._MEIPASS)

def parse_version(output):
    match=re.search(r'^Blender\s+(\d+)\.(\d+)(?:\.(\d+))?',output,re.MULTILINE)
    if not match:raise ValueError('无法识别 Blender 版本，请选择安装文件夹中的 blender.exe。')
    return tuple(int(v or 0) for v in match.groups())

@lru_cache(maxsize=32)
def _inspect(path,mtime,size):
    proc=spawn([path,'--version'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,encoding='utf-8',errors='replace')
    try:output,_=proc.communicate(timeout=8)
    except subprocess.TimeoutExpired:
        proc.kill();proc.communicate()
        raise ValueError('Blender 版本检测超时，请重新选择 blender.exe。') from None
    if proc.returncode:raise ValueError('Blender 无法启动，请检查程序是否完整解压。')
    version=parse_version(output)
    return {'path':path,'version':list(version),'label':'Blender '+'.'.join(map(str,version)),
            'supported':MIN_VERSION<=version<MAX_VERSION}

def inspect_blender(path,require_supported=True):
    p=Path(path).expanduser().resolve()
    if not p.is_file() or p.name.lower() not in ('blender.exe','blender'):
        raise ValueError('请选择 Blender 安装文件夹中的 blender.exe，不要填写版本号或文件夹。')
    stat=p.stat();info=dict(_inspect(str(p),stat.st_mtime_ns,stat.st_size))
    if require_supported and not info['supported']:
        raise ValueError(f"检测到 {info['label']}。当前支持 {SUPPORTED_TEXT}，请切换到此范围内的版本。")
    return info

def discover_candidates():
    candidates=[]
    override=os.environ.get('BLENDER_EXECUTABLE')
    if override:candidates.append(Path(override))
    for anchor in [Path(__file__).resolve(),Path(sys.executable).resolve(),Path.cwd()/'app.py']:
        for parent in list(anchor.parents)[:6]:candidates.append(parent/'blender.exe')
    found=shutil.which('blender')
    if found:candidates.append(Path(found))
    roots=[Path('C:/Program Files/Blender Foundation'),Path('D:/software'),
           Path.home()/'Downloads',Path(os.environ.get('LOCALAPPDATA',Path.home()))/'Programs/Blender Foundation']
    for root in roots:
        if root.is_dir():
            for pattern in ['Blender*/blender.exe','blender*/blender.exe']:
                candidates.extend(root.glob(pattern))
    candidates.extend([Path('C:/Program Files (x86)/Steam/steamapps/common/Blender/blender.exe'),
                       Path('C:/Program Files/Steam/steamapps/common/Blender/blender.exe')])
    seen=set()
    for p in candidates:
        try:
            key=os.path.normcase(str(p.resolve()))
            if key not in seen and p.is_file():seen.add(key);yield p
        except OSError:continue

def find_installations():
    results=[]
    for path in discover_candidates():
        try:results.append(inspect_blender(path,require_supported=False))
        except (OSError,ValueError):continue
    return sorted(results,key=lambda x:(x['supported'],x['version']),reverse=True)

def find_blender():
    return next((item['path'] for item in find_installations() if item['supported']),'')
