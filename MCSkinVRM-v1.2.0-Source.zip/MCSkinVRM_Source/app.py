import sys,json
if __name__=='__main__':
    if '--self-test' in sys.argv:
        import tkinter as tk
        from mcvrm.jobs import resources
        root=tk.Tk();root.withdraw()
        assert (resources()/'blender_backend.py').exists()
        assert (resources()/'addons/io_scene_vrm/__init__.py').exists()
        root.destroy()
        sys.exit(0)
    from mcvrm.gui import main
    main()
