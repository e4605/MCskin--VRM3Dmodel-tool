"""Single and batch conversion from source; GUI is the packaged entry point."""
import argparse,json,sys
from pathlib import Path
from mcvrm.jobs import find_blender,prepare,run
from mcvrm.blender import inspect_blender,find_installations
from mcvrm.batch import convert_batch
from mcvrm.options import normalize_options
from mcvrm import __version__

def main():
    p=argparse.ArgumentParser(description='Convert MC skins to VRM 0.x using Blender 4.2--5.2, without added mouth geometry.')
    p.add_argument('skin',nargs='*');p.add_argument('--output');p.add_argument('--blender',default='')
    p.add_argument('--version',action='version',version=__version__)
    p.add_argument('--list-blenders',action='store_true',help='List detected Blender executables and versions')
    p.add_argument('--batch',action='store_true',help='Convert multiple PNGs or folders; faces remain static')
    p.add_argument('--name',default='');p.add_argument('--author',default='Skin owner')
    p.add_argument('--model',choices=['auto','classic','slim'],default='auto');p.add_argument('--height',type=float,default=1.8)
    p.add_argument('--eyes',help='Optional eye pixel profile JSON, single-skin conversion only')
    p.add_argument('--keep-opaque-overlay',action='store_true');p.add_argument('--no-preview',action='store_true')
    p.add_argument('--preview-quality',choices=['fast','standard','high'],default='fast')
    p.add_argument('--views',action='store_true',help='Also render front, side and back PNGs')
    p.add_argument('--wave-demo',action='store_true',help='Add an animated wave to the Blender project only')
    p.add_argument('--no-blend',action='store_true',help='Skip the editable Blender project')
    p.add_argument('--timeout-minutes',type=float,default=15)
    a=p.parse_args()
    if a.list_blenders:print(json.dumps(find_installations(),ensure_ascii=False,indent=2));return 0
    if not a.skin or not a.output:p.error('skin and --output are required for conversion')
    if a.views and a.no_preview:p.error('--views cannot be combined with --no-preview')
    opts=normalize_options({'save_blend':not a.no_blend,'preview_quality':a.preview_quality,'preview_views':a.views,
           'demo_animation':a.wave_demo,'timeout_seconds':a.timeout_minutes*60})
    blender=a.blender or find_blender();inspect_blender(blender)
    batch=a.batch or len(a.skin)>1
    if batch:
        if a.eyes:p.error('--eyes is single-skin only; batch faces remain static')
        paths=[]
        for value in a.skin:
            path=Path(value)
            paths.extend(sorted(x for x in path.iterdir() if x.is_file() and x.suffix.lower()=='.png') if path.is_dir() else [path])
        folder,result=convert_batch(blender,paths,a.output,model=a.model,height=a.height,author=a.author,
              opaque_fix=not a.keep_opaque_overlay,preview=not a.no_preview,options=opts,
              on_progress=lambda percent,message:print(f'{percent:5.1f}% {message}',flush=True))
        print('OUTPUT',str(folder));print(json.dumps(result,ensure_ascii=False,indent=2))
        return 130 if result['cancelled'] else (1 if result['failed'] else 0)
    eyes=None
    if a.eyes:
        with open(a.eyes,encoding='utf-8-sig') as f:eyes=json.load(f)
    out,job=prepare(a.skin[0],a.output,a.name,a.model,a.height,eyes,not a.keep_opaque_overlay,not a.no_preview,a.author,opts)
    print('OUTPUT',str(out),flush=True)
    report=run(blender,out,lambda percent,message:print(f'{percent:3d}% {message}',flush=True))
    print(json.dumps(report,ensure_ascii=False,indent=2));return 0

if __name__=='__main__':
    for stream in [sys.stdout,sys.stderr]:
        if stream and hasattr(stream,'reconfigure'):stream.reconfigure(encoding='utf-8',errors='replace')
    try:sys.exit(main())
    except KeyboardInterrupt:print('转换已取消。',file=sys.stderr);sys.exit(130)
    except Exception as error:print('ERROR:',str(error),file=sys.stderr);sys.exit(1)
