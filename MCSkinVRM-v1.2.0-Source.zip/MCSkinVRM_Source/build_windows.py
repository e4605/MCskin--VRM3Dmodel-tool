"""Run with the developer's Python and PyInstaller installed; creates a portable folder."""
from pathlib import Path
import subprocess,sys,os,shutil,tempfile
from PIL import Image,ImageDraw
from mcvrm import __version__
ROOT=Path(__file__).resolve().parent
icon=Image.new('RGBA',(256,256),(12,20,35,255));d=ImageDraw.Draw(icon)
d.polygon([(128,38),(220,88),(128,139),(36,88)],fill='#86e8ca')
d.polygon([(36,88),(128,139),(128,230),(36,178)],fill='#2a937b')
d.polygon([(128,139),(220,88),(220,178),(128,230)],fill='#52c6aa')
d.line([(128,38),(128,139),(128,230)],fill='#c9ffef',width=4)
icon.save(ROOT/'resources/app.ico',sizes=[(16,16),(32,32),(48,48),(128,128),(256,256)])
env=os.environ.copy();env['PYTHONPATH']=str(ROOT/'build_deps')+os.pathsep+str(ROOT)
with tempfile.TemporaryDirectory(prefix='.build_resources_',dir=ROOT) as temporary:
    staging=Path(temporary).resolve();assert staging.is_relative_to(ROOT.resolve())
    clean=staging/'resources'
    shutil.copytree(ROOT/'resources',clean,ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.pyo'))
    args=[sys.executable,'-m','PyInstaller','--noconfirm','--clean','--windowed','--name','MCSkinVRM',
          '--distpath',str(ROOT/'dist'/__version__),'--workpath',str(ROOT/'build'/__version__),
          '--icon',str(ROOT/'resources/app.ico'),'--add-data',str(clean)+os.pathsep+'resources',
          '--paths',str(ROOT),'--exclude-module','numpy','--exclude-module','matplotlib','--exclude-module','bpy',str(ROOT/'app.py')]
    subprocess.run(args,cwd=ROOT,env=env,check=True)
target=ROOT/'dist'/__version__/'MCSkinVRM'
for filename in ['README.md','CHANGELOG.md','使用说明.md','研究与兼容性.md','THIRD_PARTY_NOTICES.md','LICENSE']:
    if (ROOT/filename).exists():shutil.copy2(ROOT/filename,target/filename)
if (ROOT/'licenses').exists():shutil.copytree(ROOT/'licenses',target/'licenses',dirs_exist_ok=True)
print('PORTABLE_BUILD_READY',target,flush=True)
