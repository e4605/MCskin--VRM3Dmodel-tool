import bpy,json
from mathutils import Vector
for o in bpy.data.objects:
    item={'name':o.name,'type':o.type,'location':list(o.location),'scale':list(o.scale)}
    if o.type=='MESH':
        e=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=e.to_mesh()
        points=[e.matrix_world@v.co for v in m.vertices]
        item['bounds']=[[min(p[i] for p in points),max(p[i] for p in points)] for i in range(3)]
        e.to_mesh_clear()
    print('OBJECT_QA '+json.dumps(item))
