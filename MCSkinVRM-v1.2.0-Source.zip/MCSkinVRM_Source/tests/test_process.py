"""Process isolation and cancellation regression using an actual Blender child."""
import unittest,tempfile,threading
from pathlib import Path
from mcvrm.jobs import find_blender,prepare,run
from test_skin import fixture

class ProcessTests(unittest.TestCase):
    @unittest.skipUnless(find_blender(),'Requires a local Blender executable')
    def test_cancel_terminates_only_the_started_child(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);fixture(root/'input.png')
            out,_=prepare(root/'input.png',root/'exports',preview=False)
            cancelled=threading.Event();created=[]
            def on_process(proc):
                created.append(proc);cancelled.set();proc.terminate()
            with self.assertRaises(InterruptedError):run(find_blender(),out,cancel=cancelled,on_process=on_process)
            self.assertEqual(len(created),1)
            self.assertIsNotNone(created[0].poll())
            self.assertFalse((out/'Avatar.vrm').exists())
            self.assertTrue((root/'input.png').exists())

if __name__=='__main__':unittest.main()
