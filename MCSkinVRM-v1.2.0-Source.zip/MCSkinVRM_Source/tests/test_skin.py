import unittest,tempfile,json
from pathlib import Path
from PIL import Image
from mcvrm.skin import read_skin,rectangles,PARTS,validate_eyes
from mcvrm.jobs import prepare

def fixture(path,size=64,legacy=False):
    k=size//64;im=Image.new('RGBA',(size,size),(0,0,0,0))
    for n,(_,base,_,w,h,d) in enumerate(PARTS):
        for x,y,rw,rh in rectangles(base,w or 4,h,d):
            for py in range(y*k,(y+rh)*k):
                for px in range(x*k,(x+rw)*k):im.putpixel((px,py),((px*3+30)%256,(py*3+40)%256,70+n*20,255))
    # A small opaque / translucent outer-layer detail tests layer alpha handling.
    im.paste((128,255,255,2),(35*k,38*k,36*k,39*k))
    if legacy:im=im.crop((0,0,size,size//2))
    im.save(path);return im

class SkinTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def test_classic_inference_and_faint_layer(self):
        p=self.root/'classic.png';original=fixture(p)
        im,info=read_skin(p)
        self.assertEqual(info['model'],'classic')
        self.assertEqual(im.getpixel((35,38)),(128,255,255,2))
        self.assertEqual(im.tobytes(),original.tobytes())
    def test_legacy_mirror_orientation(self):
        p=self.root/'old.png';source=fixture(p,legacy=True)
        im,info=read_skin(p)
        self.assertTrue(info['legacy']);self.assertEqual(info['model'],'classic')
        self.assertEqual(im.getpixel((20,52)),source.getpixel((7,20)))
        self.assertEqual(im.getpixel((23,63)),source.getpixel((4,31)))
        self.assertEqual(im.getpixel((24,52)),source.getpixel((3,20)))
        self.assertEqual(im.getpixel((36,52)),source.getpixel((47,20)))
        with self.assertRaises(ValueError):read_skin(p,'slim')
    def test_hd_keeps_every_subpixel(self):
        p=self.root/'hd.png';fixture(p,128)
        im,info=read_skin(p,'classic')
        self.assertEqual(info['scale'],2)
        self.assertNotEqual(im.getpixel((40,40)),im.getpixel((41,40)))
    def test_fully_opaque_background_is_explicitly_fixable(self):
        p=self.root/'rgb.png';Image.new('RGB',(64,64),(80,110,130)).save(p)
        im,info=read_skin(p,'classic',True);self.assertEqual(im.getpixel((40,8))[3],0)
        im,info=read_skin(p,'classic',False);self.assertEqual(im.getpixel((40,8))[3],255)
    def test_invalid_input_and_mislabelled_jpeg(self):
        p=self.root/'invalid.png';Image.new('RGBA',(63,64)).save(p)
        with self.assertRaises(ValueError):read_skin(p)
        Image.new('RGB',(64,64)).save(p,format='JPEG')
        with self.assertRaises(ValueError):read_skin(p)
    def test_eye_validation(self):
        with self.assertRaises(ValueError):validate_eyes({'left':[[1,1]],'right':[[1,1]]})
        with self.assertRaises(ValueError):validate_eyes({'left':[[8,1]],'right':[[6,1]]})
        with self.assertRaises(ValueError):validate_eyes({'left':[[1,1]],'right':[[6,1]],'left_lid':[1,1]})
        self.assertEqual(validate_eyes({'left':[[1,1]],'right':[[6,1]]})['left'],[(1,1)])
    def test_jobs_do_not_overwrite_or_escape(self):
        p=self.root/'input.png';fixture(p)
        dest=self.root/'exports'
        a,_=prepare(p,dest,name='../CON');b,_=prepare(p,dest,name='../CON')
        self.assertNotEqual(a,b);self.assertTrue(a.is_relative_to(dest))
        self.assertTrue((a/'job.json').exists());self.assertEqual((a/'input_skin.png').read_bytes(),p.read_bytes())
        with self.assertRaises(ValueError):prepare(p,dest,height=99)

if __name__=='__main__':unittest.main()
