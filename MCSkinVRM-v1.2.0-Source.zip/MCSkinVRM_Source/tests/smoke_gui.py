"""Application-level smoke check without sending any desktop input."""
from pathlib import Path
from types import SimpleNamespace
import sys,json
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import mcvrm.gui as gui
from mcvrm.advanced import AdvancedDialog,QUALITY
from mcvrm.options import DEFAULTS
from test_skin import fixture
gui.SETTINGS=ROOT/'test_outputs/ui_smoke_settings_v12.json'
gui.SETTINGS.parent.mkdir(exist_ok=True)
gui.SETTINGS.write_text('[]',encoding='utf-8')
app=gui.App();app.withdraw();app.demo();app.detect_blender()
assert Path(app.blender.get()).name.lower()=='blender.exe'
editor=gui.EyeEditor(app,app.normalized,None,lambda p:(setattr(app,'eye_profile',p),app.eyes.set(True)))
editor.withdraw();editor.example()
assert editor.is_qwq
assert len(editor.profile['left'])==len(editor.profile['right'])==5
editor.click(SimpleNamespace(x=5*48+24,y=5*48+24))
assert len(editor.profile['left'])==4
editor.click(SimpleNamespace(x=5*48+24,y=5*48+24))
assert len(editor.profile['left'])==5
bad_profile=ROOT/'test_outputs/invalid_eye_profile.json';bad_profile.write_text('{}',encoding='utf-8')
before=json.dumps(editor.profile)
with patch('mcvrm.gui.filedialog.askopenfilename',return_value=str(bad_profile)),patch('mcvrm.gui.messagebox.showerror') as failure:
    editor.load();assert failure.called
assert json.dumps(editor.profile)==before
editor.accept();assert app.eyes.get() and len(app.eye_profile['left'])==5
advanced=AdvancedDialog(app);advanced.withdraw();advanced.demo.set(True);advanced.demo_changed();advanced.views.set(True)
advanced.quality.set(next(label for label,key in QUALITY.items() if key=='fast'))
assert advanced.apply();assert app.advanced_options['demo_animation'] and app.preview.get()
app.update_idletasks()
assert 'TickIndicator' in app.tk.call('ttk::style','element','names')
app.output.set(str(ROOT/'test_outputs'));app.name.set('UI_v1_2');app.start()
errors=[];stage='single';result={}
original_error=gui.messagebox.showerror
gui.messagebox.showerror=lambda *args,**kwargs:errors.append(str(args))
def done():
    global stage
    if app.busy:app.after(200,done);return
    try:
        assert not errors,errors
        if stage=='single':
            report=json.loads((app.last_output/'report.json').read_text(encoding='utf-8'))
            assert report['texture_pixels_verified'] and report['roundtrip_import']
            assert report['converter_version']=='1.2.0' and report['demo_wave_in_blend']
            assert 'Blink' in report['shape_keys'] and len(report['preview_files'])==4
            result.update({'output':str(app.last_output),'eye_toggle':True,'eye_apply':True,'invalid_eye_config_preserved':True,
                           'automatic_blender':True,'check_indicator':True,'roundtrip':True,'advanced':True})
            second=ROOT/'test_outputs/batch_classic.png';fixture(second)
            bad=ROOT/'test_outputs/batch_bad.png';bad.write_bytes(b'bad image')
            app.advanced_options=DEFAULTS.copy();app.advanced_options['save_blend']=False;app.preview.set(False)
            stage='batch';app.start_batch([gui.resources()/'samples/qwq.png',second,bad]);app.after(200,done);return
        summary=json.loads((app.last_output/'batch_results.json').read_text(encoding='utf-8'))
        assert summary['succeeded']==2 and summary['failed']==1
        result.update({'batch_output':str(app.last_output),'batch_succeeded':2,'batch_failed':1})
        (ROOT/'gui_smoke_result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        print('GUI_FLOW_SMOKE_PASSED',flush=True)
    except Exception as error:errors.append(repr(error))
    app.destroy()
app.after(200,done)
def timeout():errors.append('GUI smoke timeout');app.cancel();app.destroy()
app.after(240000,timeout)
app.mainloop()
gui.messagebox.showerror=original_error
if errors:raise RuntimeError(errors)
