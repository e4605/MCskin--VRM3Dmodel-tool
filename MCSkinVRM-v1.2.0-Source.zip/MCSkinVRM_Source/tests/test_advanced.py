import unittest,tempfile,threading,json,sys,time
from pathlib import Path
from unittest.mock import patch
from test_skin import fixture
from mcvrm.blender import parse_version,inspect_blender,find_installations
from mcvrm.options import normalize_options
from mcvrm.skin import validate_eyes
from mcvrm.jobs import prepare,prepare_with_fallback,run
from mcvrm.batch import convert_batch

class CompatibilityTests(unittest.TestCase):
    def test_version_output_and_supported_boundaries(self):
        for value in ['4.2.23','4.5.15','5.2.3']:
            self.assertEqual(parse_version('Blender '+value+' LTS\nBuild date: today'),tuple(map(int,value.split('.'))))
        with self.assertRaises(ValueError):parse_version('Not Blender')
        with tempfile.TemporaryDirectory() as temp:
            exe=Path(temp)/'blender.exe';exe.write_bytes(b'test')
            for version,supported in [([4,1,0],False),([4,2,0],True),([5,2,3],True),([5,3,0],False)]:
                info={'path':str(exe),'version':version,'label':'Blender '+'.'.join(map(str,version)),'supported':supported}
                with patch('mcvrm.blender._inspect',return_value=info):
                    self.assertEqual(inspect_blender(exe,False)['supported'],supported)
                    if not supported:
                        with self.assertRaises(ValueError):inspect_blender(exe)
    def test_options_reject_bad_settings_and_invalid_eye_json(self):
        for value in [{'timeout_seconds':float('nan')},{'timeout_seconds':True},{'preview_quality':[]},{'save_blend':'yes'},
                      {'save_blend':False,'demo_animation':True}]:
            with self.assertRaises(ValueError):normalize_options(value)
        with self.assertRaises(ValueError):validate_eyes([])
        with self.assertRaises(ValueError):validate_eyes({'left':[[1,1]],'right':[[6,1]],'left_lid':4})

class BatchAndProcessTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.skin=self.root/'first.png';fixture(self.skin)
    def tearDown(self):self.temp.cleanup()
    def test_empty_output_and_nonfinite_height_do_not_create_jobs(self):
        with self.assertRaises(ValueError):prepare_with_fallback(self.skin,'')
        with self.assertRaises(ValueError):prepare(self.skin,self.root/'out',height=float('nan'))
        self.assertFalse((self.root/'out').exists())
    def test_batch_continues_after_bad_skin_and_deduplicates(self):
        second=self.root/'second.png';fixture(second);bad=self.root/'bad.png';bad.write_bytes(b'invalid')
        with patch('mcvrm.batch.inspect_blender',return_value={'label':'Blender test'}),patch('mcvrm.batch.run',return_value={}):
            folder,result=convert_batch('blender.exe',[self.skin,bad,second,self.skin],self.root/'out',preview=False)
        self.assertEqual((result['total'],result['succeeded'],result['failed']),(3,2,1))
        self.assertEqual(result['not_started'],0)
        saved=json.loads((folder/'batch_results.json').read_text(encoding='utf-8'))
        self.assertEqual(saved['items'][1]['status'],'error')
        for item in saved['items']:
            if item['status']=='success':self.assertIsNone(json.loads((Path(item['output'])/'job.json').read_text(encoding='utf-8'))['eyes'])
    def test_batch_cancel_keeps_completed_results(self):
        event=threading.Event();second=self.root/'second.png';fixture(second)
        def finished(*a,**k):event.set()
        with patch('mcvrm.batch.inspect_blender',return_value={'label':'Blender test'}),patch('mcvrm.batch.run',side_effect=finished):
            _,result=convert_batch('blender.exe',[self.skin,second],self.root/'out',cancel=event,preview=False)
        self.assertTrue(result['cancelled']);self.assertEqual(result['succeeded'],1);self.assertEqual(result['not_started'],1)
    def test_timeout_stops_a_silent_child(self):
        out,_=prepare(self.skin,self.root/'out',preview=False);children=[]
        with patch('mcvrm.jobs.command',return_value=[sys.executable,'-c','import time; time.sleep(30)']):
            started=time.monotonic()
            with self.assertRaises(TimeoutError):run('ignored',out,on_process=children.append,timeout_seconds=.2)
        self.assertLess(time.monotonic()-started,5);self.assertIsNotNone(children[0].poll())
    def test_cancel_stops_a_silent_child_without_gui_terminate(self):
        out,_=prepare(self.skin,self.root/'out',preview=False);event=threading.Event();children=[]
        timer=threading.Timer(.2,event.set);timer.start()
        try:
            with patch('mcvrm.jobs.command',return_value=[sys.executable,'-c','import time; time.sleep(30)']):
                with self.assertRaises(InterruptedError):run('ignored',out,cancel=event,on_process=children.append)
        finally:timer.cancel()
        self.assertIsNotNone(children[0].poll())
    def test_callback_failure_does_not_leave_child_running(self):
        out,_=prepare(self.skin,self.root/'out',preview=False);children=[]
        def broken(proc):children.append(proc);raise RuntimeError('UI callback failed')
        with patch('mcvrm.jobs.command',return_value=[sys.executable,'-c','import time; time.sleep(30)']):
            with self.assertRaisesRegex(RuntimeError,'callback'):run('ignored',out,on_process=broken)
        self.assertIsNotNone(children[0].poll())

if __name__=='__main__':unittest.main()
