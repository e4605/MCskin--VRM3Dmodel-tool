"""Run inside Blender on an exported project to verify the motion is real."""
import bpy,sys,json,math
from pathlib import Path
args=sys.argv[sys.argv.index('--')+1:];target=Path(args[0])
rig=next(o for o in bpy.data.objects if o.type=='ARMATURE')
assert rig.animation_data and rig.animation_data.action.name=='MC_Wave_Demo'
assert 'Cube' not in bpy.data.objects
arm=bpy.data.objects['rightArm_Base']
def coordinates(frame):
    bpy.context.scene.frame_set(frame)
    evaluated=arm.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=evaluated.to_mesh()
    points=[evaluated.matrix_world@v.co for v in mesh.vertices];evaluated.to_mesh_clear();return points
a=coordinates(22);b=coordinates(32)
motion=max((pa-pb).length for pa,pb in zip(a,b))
assert motion>.005,('Wrist animation did not deform the mesh',motion)
assert all(math.isfinite(value) for point in a+b for value in point)
target.write_text(json.dumps({'blender_version':list(bpy.app.version),'wave_max_vertex_motion_m':motion,
    'action':'MC_Wave_Demo','frames':[22,32],'packed_images':all(i.packed_file for i in bpy.data.images if i.type=='IMAGE' and i.has_data)},indent=2),encoding='utf-8')
print('ADVANCED_BLEND_QA_PASSED',motion,flush=True)
