"""Download official portable builds for local compatibility tests, with SHA-256."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]/'compat_runtimes'
ROOT.mkdir(exist_ok=True)
def fetch(version):
    series='.'.join(version.split('.')[:2]);name=f'blender-{version}-windows-x64.zip'
    base=f'https://download.blender.org/release/Blender{series}/'
    manifest=urllib.request.urlopen(base+f'blender-{version}.sha256',timeout=30).read().decode()
    expected=next(line.split()[0].lower() for line in manifest.splitlines() if line.rstrip().endswith(name))
    archive=ROOT/name;dest=ROOT/name.removesuffix('.zip')
    if (dest/'blender.exe').is_file():return {'version':version,'executable':str(dest/'blender.exe')}
    if not archive.exists():
        partial=archive.with_suffix('.part');count=0;last=0
        with urllib.request.urlopen(base+name,timeout=45) as remote,partial.open('wb') as local:
            while chunk:=remote.read(1024*1024):
                local.write(chunk);count+=len(chunk)
                if count-last>=64*1024*1024:print('DOWNLOAD',version,count//1048576,'MiB',flush=True);last=count
        partial.rename(archive)
    digest=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()
    if digest!=expected:raise ValueError(f'Official checksum mismatch: {version}')
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            if not (ROOT/item.filename).resolve().is_relative_to(ROOT.resolve()):raise ValueError('Unsafe archive path')
        z.extractall(ROOT)
    result={'version':version,'executable':str(dest/'blender.exe'),'sha256':digest,'source':base+name}
    (ROOT/f'{version}.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print('READY',version,flush=True);return result
if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(fetch,['4.2.23','4.5.15']))
    (ROOT/'runtimes.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
