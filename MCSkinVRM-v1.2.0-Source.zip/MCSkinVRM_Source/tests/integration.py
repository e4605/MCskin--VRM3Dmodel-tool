"""Exercise the actual bundled exporter and re-import path on different layouts."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from test_skin import fixture
from mcvrm.jobs import prepare,run,find_blender
ROOT=Path(__file__).resolve().parents[1]
FIXTURES=ROOT/'test_fixtures';FIXTURES.mkdir(exist_ok=True)
for name,size,legacy in [('classic',64,False),('legacy',64,True),('hd',128,False),('hd256',256,False)]:fixture(FIXTURES/(name+'.png'),size,legacy)
summaries=[]
for name in ['classic','legacy','hd','hd256']:
    out,job=prepare(FIXTURES/(name+'.png'),ROOT/'test_outputs',name=name,preview=name=='classic',model='classic',height=1.5 if name=='legacy' else 1.8)
    print('RUN',name,str(out),flush=True)
    report=run(find_blender(),out,lambda p,m:print(name,p,m,flush=True))
    assert report['texture_pixels_verified'] and report['roundtrip_import'] and report['humanoid_mappings']==51
    summaries.append({'case':name,'output':str(out),'vertices':report['vertices'],'triangles':report['triangles'],'roundtrip':True,'texture_pixels_verified':True})
assert summaries[2]['vertices']==summaries[0]['vertices']*4
assert summaries[3]['vertices']==summaries[0]['vertices']*16
(ROOT/'integration_results.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2),encoding='utf-8')
print('INTEGRATION_PASSED',flush=True)
