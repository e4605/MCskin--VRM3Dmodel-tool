from pathlib import Path
import json,sys,subprocess,os
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PIL import Image
from test_skin import fixture
from mcvrm.jobs import prepare,run
from mcvrm.blender import inspect_blender
from mcvrm.validation import parse

eyes={'left':[[5,5],[6,5],[5,6],[6,6],[7,6]],'right':[[1,5],[2,5],[1,6],[2,6],[0,6]],'left_lid':[5,4],'right_lid':[1,4]}
runtimes=json.loads((ROOT/'compat_runtimes/runtimes.json').read_text(encoding='utf-8'))
runtimes.append({'executable':str(ROOT.parent/'blender.exe')})
fixtures=ROOT/'test_fixtures';fixtures.mkdir(exist_ok=True)
for name,size,old in [('classic',64,False),('legacy',64,True),('hd',128,False)]:fixture(fixtures/(name+'.png'),size,old)
results=[]
for index,runtime in enumerate(runtimes):
    blender=runtime['executable'];info=inspect_blender(blender)
    out,job=prepare(ROOT/'resources/samples/qwq.png',ROOT/'test_outputs',name='Advanced_'+info['label'],eyes=eyes,
       options={'preview_quality':['fast','standard','high'][index],'preview_views':index==0,'demo_animation':True})
    print('RUN',info['label'],'advanced',flush=True)
    report=run(blender,out,lambda p,m:print(info['label'],p,m,flush=True))
    assert report['roundtrip_import'] and report['texture_pixels_verified'] and report['demo_wave_in_blend']
    expected=[(512,640),(800,1000),(1024,1280)][index]
    with Image.open(out/'preview.png') as image:assert image.size==expected
    if index==0:assert all((out/('preview_'+side+'.png')).exists() for side in ['front','side','back'])
    doc,_=parse(out/'Avatar.vrm');assert not doc.get('animations')
    with (out/'blend_qa.log').open('w',encoding='utf-8') as log:
        subprocess.run([blender,'--background',str(out/'Avatar.blend'),'--python-exit-code','1','--python',str(ROOT/'tests/inspect_advanced_blend.py'),'--',str(out/'blend_qa.json')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
    qa=json.loads((out/'blend_qa.json').read_text(encoding='utf-8'));assert qa['packed_images']
    results.append({'blender':info['label'],'case':'slim_eyes_preview_wave','output':str(out),'roundtrip':True,'pixels':True,'wave_motion_m':qa['wave_max_vertex_motion_m']})
    for name in ['classic','legacy','hd']:
        out,job=prepare(fixtures/(name+'.png'),ROOT/'test_outputs',name=info['label']+'_'+name,preview=False,model='classic',options={'save_blend':False})
        print('RUN',info['label'],name,flush=True);report=run(blender,out)
        assert report['roundtrip_import'] and report['texture_pixels_verified'] and not (out/'Avatar.blend').exists()
        results.append({'blender':info['label'],'case':name,'roundtrip':True,'pixels':True,'vertices':report['vertices']})
    (ROOT/'compatibility_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print('COMPATIBILITY_MATRIX_PASSED',flush=True)
