from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
import json,os,threading,queue,sys
from PIL import Image,ImageTk,ImageDraw
from .jobs import find_blender,prepare,run,resources
from .skin import read_skin,validate_eyes

BG='#0c1423';PANEL='#162338';FIELD='#101b2d';TEXT='#edf3fc';MUTED='#a4b6cc';ACCENT='#54ddb9'
SETTINGS=Path(os.environ.get('APPDATA',Path.home()))/'MCSkinVRM/settings.json'
EXAMPLE_EYES={'left':[[5,5],[6,5],[5,6],[6,6],[7,6]],'right':[[1,5],[2,5],[1,6],[2,6],[0,6]],'left_lid':[5,4],'right_lid':[1,4]}

class EyeEditor(tk.Toplevel):
    def __init__(self,parent,image,profile,apply):
        super().__init__(parent);self.title('眼睛像素配置 · 底层脸部');self.configure(bg=BG);self.resizable(False,False)
        self.apply_callback=apply;self.profile=json.loads(json.dumps(profile or {'left':[],'right':[],'left_lid':None,'right_lid':None}))
        self.face=image.crop((8*image.width//64,8*image.width//64,16*image.width//64,16*image.width//64)).resize((8,8),Image.Resampling.NEAREST)
        self.mode=tk.StringVar(value='left')
        tk.Label(self,text='先选标记模式，再点击眼睛所在的格子',bg=BG,fg=TEXT,font=('Microsoft YaHei UI',14,'bold')).pack(padx=22,pady=(18,8))
        tk.Label(self,text='这里放大的是底层正脸。选中的眼睛格子显示 √；再点一次取消。',bg=BG,fg=MUTED,justify='left').pack(padx=22,pady=(0,12))
        row=ttk.Frame(self);row.pack(padx=20)
        for value,label in [('left','① 标记画面右侧眼睛'),('right','② 标记画面左侧眼睛')]:
            ttk.Radiobutton(row,text=label,value=value,variable=self.mode).pack(side='left',padx=4)
        row=ttk.Frame(self);row.pack(padx=20,pady=(8,0))
        for value,label in [('left_lid','右侧闭眼底色（可跳过）'),('right_lid','左侧闭眼底色（可跳过）'),('erase','擦除眼睛标记')]:
            ttk.Radiobutton(row,text=label,value=value,variable=self.mode).pack(side='left',padx=4)
        area=ttk.Frame(self);area.pack(padx=22,pady=12)
        self.canvas=tk.Canvas(area,width=384,height=384,bg=FIELD,highlightthickness=0);self.canvas.pack(side='left')
        guide=tk.Frame(area,bg=FIELD,width=300);guide.pack(side='left',fill='y',padx=(16,0));guide.pack_propagate(False)
        for label,color in [('怎么选？',TEXT),('1  选上方的①，用鼠标逐格点选画面右侧整只眼睛。', '#fa7474'),('2  再选②，点选画面左侧整只眼睛。','#46c7ff'),('眼白、高光和瞳孔都要选；别选旁边皮肤、头发、腮红。',TEXT),('3  闭眼底色可跳过。需要时，在眼睛旁选一格肤色，用来填补闭眼后露出的位置。',MUTED),('qwq 示例：选下半张脸的灰色眼睛。上方黑点和橙色鸡喙属于帽子，不要选。',ACCENT),('4  检查两边都有 √，再点底部“应用并启用眨眼”。',TEXT)]:
            tk.Label(guide,text=label,bg=FIELD,fg=color,wraplength=276,justify='left',anchor='w',font=('Microsoft YaHei UI',9)).pack(fill='x',padx=12,pady=(8,0))
        self.photo=ImageTk.PhotoImage(self.face.resize((384,384),Image.Resampling.NEAREST));self.canvas.bind('<Button-1>',self.click)
        self.info=tk.Label(self,text='',bg=BG,fg=MUTED);self.info.pack()
        actions=ttk.Frame(self);actions.pack(fill='x',padx=22,pady=12)
        ttk.Button(actions,text='qwq 一键示范（选好两只眼睛）',command=self.example).pack(side='left')
        ttk.Button(actions,text='清空',command=self.clear).pack(side='left',padx=8)
        ttk.Button(actions,text='保存配置…',command=self.save).pack(side='left')
        ttk.Button(actions,text='读取…',command=self.load).pack(side='left',padx=8)
        self.mode_hint=tk.Label(self,text='',bg=BG,fg=ACCENT,wraplength=650);self.mode_hint.pack(padx=22,pady=(0,8))
        self.mode.trace_add('write',lambda *_:self.redraw())
        ttk.Button(self,text='应用并启用眨眼',style='Accent.TButton',command=self.accept).pack(fill='x',padx=22,pady=(0,20))
        self.redraw();self.transient(parent);self.grab_set()
    def redraw(self):
        c=self.canvas;c.delete('all');c.create_image(0,0,anchor='nw',image=self.photo)
        for n in range(9):c.create_line(n*48,0,n*48,384,fill='#8391a1');c.create_line(0,n*48,384,n*48,fill='#8391a1')
        for key,color in [('left','#fa7474'),('right','#46c7ff')]:
            for x,y in self.profile[key]:
                c.create_rectangle(x*48+3,y*48+3,(x+1)*48-3,(y+1)*48-3,outline=color,width=3)
                c.create_rectangle(x*48+28,y*48+4,x*48+44,y*48+23,fill=FIELD,outline='')
                c.create_text(x*48+36,y*48+14,text='√',fill=color,font=('Microsoft YaHei UI',13,'bold'))
            lid=self.profile.get(key+'_lid')
            if lid:c.create_oval(lid[0]*48+16,lid[1]*48+16,lid[0]*48+32,lid[1]*48+32,outline=color,width=4)
        self.info.configure(text=f"红框 · 画面右侧 {len(self.profile['left'])} 格   |   蓝框 · 画面左侧 {len(self.profile['right'])} 格   |   圆圈 = 底色取样")
        hints={'left':'当前：点击画面右侧眼睛的格子，出现红框和 √。','right':'当前：点击画面左侧眼睛的格子，出现蓝框和 √。','left_lid':'当前：选右侧眼睛旁的一格肤色，不要点眼睛本身。','right_lid':'当前：选左侧眼睛旁的一格肤色，不要点眼睛本身。','erase':'当前：点击已标记的眼睛格子，移除标记。'}
        self.mode_hint.configure(text=hints[self.mode.get()])
    def click(self,event):
        cell=[event.x//48,event.y//48]
        if any(v<0 or v>7 for v in cell):return
        mode=self.mode.get()
        if mode.endswith('_lid'):self.profile[mode]=cell
        else:
            existing=cell in self.profile.get(mode,[]) if mode!='erase' else False
            for side in ['left','right']:
                if cell in self.profile[side]:self.profile[side].remove(cell)
            if mode!='erase' and not existing:self.profile[mode].append(cell)
        self.redraw()
    def example(self):self.profile=json.loads(json.dumps(EXAMPLE_EYES));self.redraw()
    def clear(self):self.profile={'left':[],'right':[],'left_lid':None,'right_lid':None};self.redraw()
    def accept(self):
        try:p=validate_eyes(self.profile)
        except ValueError as e:messagebox.showerror('眼睛配置',str(e),parent=self);return
        self.apply_callback(p);self.destroy()
    def save(self):
        try:p=validate_eyes(self.profile)
        except ValueError as e:messagebox.showerror('眼睛配置',str(e),parent=self);return
        filename=filedialog.asksaveasfilename(parent=self,defaultextension='.json',filetypes=[('眼睛配置','*.json')],initialfile='eyes.json')
        if filename:Path(filename).write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
    def load(self):
        filename=filedialog.askopenfilename(parent=self,filetypes=[('眼睛配置','*.json')])
        if filename:
            try:self.profile=json.loads(json.dumps(validate_eyes(json.loads(Path(filename).read_text(encoding='utf-8-sig')))));self.redraw()
            except Exception as e:messagebox.showerror('读取失败',str(e),parent=self)

class App(tk.Tk):
    def __init__(self):
        super().__init__();self.title('MC Skin → VRM 1.1 · 皮肤转换器');self.geometry('1160x870');self.minsize(1100,820);self.configure(bg=BG)
        try:self.iconbitmap(default=str(resources()/'app.ico'))
        except tk.TclError:pass
        style=ttk.Style(self);style.theme_use('clam')
        style.configure('.',font=('Microsoft YaHei UI',10),background=PANEL,foreground=TEXT)
        style.configure('TFrame',background=PANEL);style.configure('TLabel',background=PANEL,foreground=TEXT)
        style.configure('Muted.TLabel',foreground=MUTED);style.configure('TButton',background='#263a54',foreground=TEXT,padding=(12,8),borderwidth=0)
        style.map('TButton',background=[('active','#335271'),('disabled','#243044')],foreground=[('disabled','#77869b')])
        style.configure('Accent.TButton',background=ACCENT,foreground='#0c2622',font=('Microsoft YaHei UI',11,'bold'))
        style.map('Accent.TButton',background=[('active','#85efd0'),('disabled','#294c48')])
        style.configure('TEntry',fieldbackground=FIELD,foreground=TEXT,insertcolor=TEXT,padding=6)
        style.map('TEntry',fieldbackground=[('readonly',FIELD)])
        style.configure('TCombobox',fieldbackground=FIELD,foreground=TEXT,arrowcolor=TEXT,padding=5)
        style.map('TCombobox',fieldbackground=[('readonly',FIELD)],foreground=[('readonly',TEXT)])
        style.configure('TCheckbutton',background=PANEL,foreground=TEXT)
        style.map('TCheckbutton',background=[('disabled',PANEL),('active',PANEL)],foreground=[('disabled',MUTED)])
        self.check_images=[]
        for selected,disabled in [(False,False),(True,False),(False,True),(True,True)]:
            im=Image.new('RGBA',(24,20),(0,0,0,0));draw=ImageDraw.Draw(im)
            draw.rounded_rectangle((1,1,18,18),radius=3,fill=('#355e55' if disabled else ACCENT) if selected else FIELD,outline=MUTED,width=1)
            if selected:draw.line([(4,9),(8,14),(15,5)],fill=TEXT if disabled else BG,width=3,joint='curve')
            self.check_images.append(ImageTk.PhotoImage(im))
        off,on,off_disabled,on_disabled=self.check_images
        style.element_create('TickIndicator','image',off,('disabled','selected',on_disabled),('selected',on),('disabled',off_disabled))
        style.layout('TCheckbutton',[('Checkbutton.padding',{'sticky':'nswe','children':[('TickIndicator',{'side':'left','sticky':'w'}),('Checkbutton.label',{'side':'left','sticky':'w'})]})])
        style.configure('TRadiobutton',background=PANEL,foreground=TEXT)
        style.configure('Horizontal.TProgressbar',troughcolor=FIELD,background=ACCENT,borderwidth=0)
        self.input_path=None;self.normalized=None;self.eye_profile=None;self.proc=None;self.busy=False;self.last_output=None
        self.cancel_event=threading.Event();self.events=queue.Queue()
        self.blender=tk.StringVar(value=find_blender());self.output=tk.StringVar(value=str(Path.home()/'Downloads/MC_VRM_Exports'))
        self.name=tk.StringVar();self.author=tk.StringVar(value='Skin owner');self.model=tk.StringVar(value='自动识别');self.height=tk.StringVar(value='1.8')
        self.eyes=tk.BooleanVar(value=False);self.opaque=tk.BooleanVar(value=True);self.preview=tk.BooleanVar(value=True)
        try:
            settings=json.loads(SETTINGS.read_text(encoding='utf-8'))
            if Path(settings.get('blender','')).is_file():self.blender.set(settings['blender'])
            self.output.set(settings.get('output',self.output.get()))
        except (OSError,ValueError):pass
        header=tk.Frame(self,bg=BG);header.pack(fill='x',padx=28,pady=(22,16))
        tk.Label(header,text='MC SKIN  →  VRM',bg=BG,fg=TEXT,font=('Segoe UI',25,'bold')).pack(anchor='w')
        tk.Label(header,text='本地转换 · 原色像素 · 双层皮肤 · 无新增嘴巴',bg=BG,fg=MUTED,font=('Microsoft YaHei UI',11)).pack(anchor='w',pady=(6,0))
        body=tk.Frame(self,bg=BG);body.pack(fill='both',expand=True,padx=28)
        left=ttk.Frame(body,padding=18);left.pack(side='left',fill='both',padx=(0,16))
        ttk.Label(left,text='01  选择皮肤',font=('Microsoft YaHei UI',13,'bold')).pack(anchor='w')
        self.canvas=tk.Canvas(left,width=340,height=330,bg=FIELD,highlightthickness=0);self.canvas.pack(pady=14)
        self.canvas.create_text(170,165,text='选择一张 MC 皮肤 PNG\n转换完成后在这里查看模型',fill=MUTED,font=('Microsoft YaHei UI',12),justify='center')
        self.file_label=ttk.Label(left,text='支持 64 / 128 / 256 像素宽\n现代方形与旧版 2:1 皮肤',style='Muted.TLabel',wraplength=340);self.file_label.pack(anchor='w')
        self.pick_btn=ttk.Button(left,text='选择皮肤 PNG…',style='Accent.TButton',command=self.pick);self.pick_btn.pack(fill='x',pady=(16,8))
        self.demo_btn=ttk.Button(left,text='使用 qwq 示例',command=self.demo);self.demo_btn.pack(fill='x')
        self.eye_btn=ttk.Button(left,text='配置眼睛像素…',command=self.eye_editor);self.eye_btn.pack(fill='x',pady=8)
        right=ttk.Frame(body,padding=20);right.pack(side='left',fill='both',expand=True)
        ttk.Label(right,text='02  转换设置',font=('Microsoft YaHei UI',13,'bold')).grid(row=0,column=0,columnspan=3,sticky='w',pady=(0,12))
        right.columnconfigure(1,weight=1)
        self.fields=[]
        def entry(row,label,var,browse=None):
            ttk.Label(right,text=label).grid(row=row,column=0,sticky='w',padx=(0,12),pady=5)
            widget=ttk.Entry(right,textvariable=var);widget.grid(row=row,column=1,sticky='ew',pady=5);self.fields.append(widget)
            if browse:
                btn=ttk.Button(right,text='浏览…',command=browse);btn.grid(row=row,column=2,padx=(8,0));self.fields.append(btn)
        entry(1,'模型名称',self.name);entry(2,'作者信息',self.author)
        ttk.Label(right,text='手臂类型').grid(row=3,column=0,sticky='w',pady=6)
        self.model_box=ttk.Combobox(right,textvariable=self.model,values=['自动识别','普通手臂（Steve）','细手臂（Alex）'],state='readonly');self.model_box.grid(row=3,column=1,columnspan=2,sticky='ew');self.model_box.bind('<<ComboboxSelected>>',lambda e:self.refresh_skin())
        entry(4,'身高（米）',self.height)
        ttk.Label(right,text='Blender 程序').grid(row=5,column=0,sticky='nw',pady=10,padx=(0,12))
        blender_row=ttk.Frame(right);blender_row.grid(row=5,column=1,columnspan=2,sticky='ew',pady=5);blender_row.columnconfigure(0,weight=1)
        be=ttk.Entry(blender_row,textvariable=self.blender);be.grid(row=0,column=0,sticky='ew');self.fields.append(be)
        for col,label,fn in [(1,'自动查找',self.detect_blender),(2,'选择程序…',self.pick_blender)]:
            btn=ttk.Button(blender_row,text=label,command=fn);btn.grid(row=0,column=col,padx=(6,0));self.fields.append(btn)
        ttk.Label(blender_row,text='选安装文件夹里的 blender.exe，不填“5.2”或安装目录。',style='Muted.TLabel',wraplength=520).grid(row=1,column=0,columnspan=3,sticky='w',pady=(5,0))
        btn=ttk.Button(right,text='不知道怎么填？查看本机示例',command=self.blender_help);btn.grid(row=6,column=1,columnspan=2,sticky='w',pady=(0,4));self.fields.append(btn)
        entry(7,'输出目录',self.output,self.pick_output)
        self.eye_check=ttk.Checkbutton(right,text='启用眨眼与视线（先点左边“配置眼睛像素”）',variable=self.eyes);self.eye_check.grid(row=8,column=0,columnspan=3,sticky='w',pady=(8,5));self.fields.append(self.eye_check)
        self.opaque_check=ttk.Checkbutton(right,text='全不透明皮肤：自动移除第二层背景',variable=self.opaque,command=self.refresh_skin);self.opaque_check.grid(row=9,column=0,columnspan=3,sticky='w',pady=4);self.fields.append(self.opaque_check)
        self.preview_check=ttk.Checkbutton(right,text='同时渲染模型预览图',variable=self.preview);self.preview_check.grid(row=10,column=0,columnspan=3,sticky='w',pady=4);self.fields.append(self.preview_check)
        ttk.Label(right,text='输出 VRM + Blender 工程 · 51 项骨骼映射 · 不新增嘴巴',style='Muted.TLabel',wraplength=580).grid(row=11,column=0,columnspan=3,sticky='w',pady=(8,10))
        self.start_btn=ttk.Button(right,text='开始转换',style='Accent.TButton',command=self.start);self.start_btn.grid(row=12,column=0,columnspan=2,sticky='ew')
        self.cancel_btn=ttk.Button(right,text='取消',command=self.cancel,state='disabled');self.cancel_btn.grid(row=12,column=2,padx=(8,0))
        self.progress=ttk.Progressbar(right,maximum=100);self.progress.grid(row=13,column=0,columnspan=3,sticky='ew',pady=(10,6))
        self.status=ttk.Label(right,text='先选择皮肤，再确认 Blender 程序路径。',style='Muted.TLabel',wraplength=580);self.status.grid(row=14,column=0,columnspan=3,sticky='w')
        self.log=tk.Text(right,height=3,bg=FIELD,fg=MUTED,font=('Microsoft YaHei UI',9),relief='flat',wrap='word',state='disabled');self.log.grid(row=15,column=0,columnspan=3,sticky='nsew',pady=(10,0));right.rowconfigure(15,weight=1)
        bottom=tk.Frame(self,bg=BG);bottom.pack(fill='x',padx=28,pady=14,before=body,side='bottom')
        tk.Label(bottom,text='所有转换均在本机完成。目标直播软件仍需实机加载验证。',bg=BG,fg=MUTED).pack(side='left')
        self.open_btn=ttk.Button(bottom,text='打开输出目录',command=self.open_output,state='disabled');self.open_btn.pack(side='right')
        self.protocol('WM_DELETE_WINDOW',self.close);self.after(120,self.poll)
    def logline(self,text):
        self.log.configure(state='normal');self.log.insert('end',text+'\n');self.log.see('end');self.log.configure(state='disabled')
    def model_id(self):return {'自动识别':'auto','普通手臂（Steve）':'classic','细手臂（Alex）':'slim'}[self.model.get()]
    def pick(self):
        name=filedialog.askopenfilename(filetypes=[('MC 皮肤 PNG','*.png')])
        if name:self.load(name)
    def demo(self):
        sample=resources()/'samples/qwq.png'
        if not sample.exists():messagebox.showinfo('示例','没有找到示例皮肤，请自行选择 PNG。');return
        self.load(sample)
    def load(self,path):
        try:
            im,info=read_skin(path,self.model_id(),self.opaque.get())
            self.input_path=Path(path);self.normalized=im;self.eye_profile=None;self.eyes.set(False);self.name.set(Path(path).stem)
            self.show_atlas(im);self.file_label.configure(text=f'{Path(path).name}\n{info["size"][0]} px · '+('Alex 细手臂' if info['model']=='slim' else 'Steve 普通手臂'))
            self.status.configure(text='皮肤已载入。默认精确还原，不新增表情或嘴巴。')
            for note in info['notes']:self.logline(note)
        except Exception as e:messagebox.showerror('皮肤无法读取',str(e))
    def refresh_skin(self):
        if not self.input_path:return
        try:
            self.normalized,info=read_skin(self.input_path,self.model_id(),self.opaque.get());self.show_atlas(self.normalized)
            self.file_label.configure(text=f'{self.input_path.name}\n{info["size"][0]} px · '+('Alex 细手臂' if info['model']=='slim' else 'Steve 普通手臂'))
        except Exception as e:messagebox.showerror('设置不匹配',str(e))
    def show_atlas(self,image):
        bg=Image.new('RGBA',(320,320),FIELD);d=ImageDraw.Draw(bg)
        for y in range(0,320,16):
            for x in range(0,320,16):
                if (x//16+y//16)%2:d.rectangle((x,y,x+15,y+15),fill='#203049')
        bg.alpha_composite(image.resize((320,320),Image.Resampling.NEAREST));self.photo=ImageTk.PhotoImage(bg)
        self.canvas.delete('all');self.canvas.create_image(170,165,image=self.photo)
    def eye_editor(self):
        if self.normalized is None:messagebox.showinfo('配置眼睛','请先选择皮肤。');return
        def apply(profile):self.eye_profile=profile;self.eyes.set(True);self.logline('眼睛像素配置已更新；无嘴设定保持不变。')
        EyeEditor(self,self.normalized,self.eye_profile,apply)
    def pick_blender(self):
        current=Path(self.blender.get())
        path=filedialog.askopenfilename(title='打开 Blender 安装文件夹，选中 blender.exe，再点“打开”',initialdir=str(current.parent) if current.is_file() else None,filetypes=[('Blender 程序（blender.exe）','blender.exe')])
        if path:self.blender.set(path)
    def detect_blender(self):
        path=find_blender()
        if path:self.blender.set(path);self.status.configure(text='已自动填入 Blender 程序路径，可继续选择皮肤并转换。')
        else:self.blender_help()
    def blender_help(self):
        example=find_blender()
        message='这里需要的是 Blender 程序文件的完整路径，不是版本号。\n\n'
        if example:message+='已找到本机程序：\n'+example+'\n\n点击“自动查找”即可填入，无需手打。\n\n'
        message+='手动选择：\n1. 点“选择程序…”\n2. 打开 Blender 5.2 的安装文件夹\n3. 选中 blender.exe，点“打开”\n\n不要选 .blend 工程、快捷方式或安装包。'
        messagebox.showinfo('Blender 程序怎么填',message,parent=self)
    def pick_output(self):
        path=filedialog.askdirectory(title='选择导出父目录')
        if path:self.output.set(path)
    def start(self):
        if not self.input_path:messagebox.showinfo('选择皮肤','请先选择 PNG。');return
        try:
            if not Path(self.blender.get()).is_file():raise ValueError('请先选择 Blender 5.2 的 blender.exe。')
            if self.eyes.get() and not self.eye_profile:raise ValueError('请先配置眼睛像素，或取消启用眨眼。')
            out,job=prepare(self.input_path,self.output.get(),self.name.get(),self.model_id(),float(self.height.get()),self.eye_profile if self.eyes.get() else None,self.opaque.get(),self.preview.get(),self.author.get())
        except Exception as e:messagebox.showerror('无法开始转换',str(e));return
        try:
            SETTINGS.parent.mkdir(parents=True,exist_ok=True)
            SETTINGS.write_text(json.dumps({'blender':self.blender.get(),'output':self.output.get()},ensure_ascii=False),encoding='utf-8')
        except OSError:self.logline('无法保存路径设置，本次转换仍可继续。')
        self.last_output=out;self.cancel_event.clear();self.proc=None;self.set_busy(True);self.progress['value']=0
        blender=self.blender.get();self.logline('输出：'+str(out));self.status.configure(text='正在启动 Blender…')
        def work():
            try:
                result=run(blender,out,lambda p,m:self.events.put(('progress',(p,m))),self.cancel_event,self.process_started)
                self.events.put(('done',(out,result)))
            except Exception as e:self.events.put(('error',str(e)))
        threading.Thread(target=work,daemon=True).start()
    def process_started(self,proc):
        self.proc=proc
        if self.cancel_event.is_set() and proc.poll() is None:proc.terminate()
    def set_busy(self,busy):
        self.busy=busy
        for w in [self.pick_btn,self.demo_btn,self.eye_btn,self.start_btn,*self.fields]:w.configure(state='disabled' if busy else 'normal')
        self.model_box.configure(state='disabled' if busy else 'readonly');self.cancel_btn.configure(state='normal' if busy else 'disabled')
    def cancel(self):
        self.cancel_event.set();self.status.configure(text='正在取消…')
        if self.proc is not None and self.proc.poll() is None:self.proc.terminate()
    def poll(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='progress':self.progress['value']=value[0];self.status.configure(text=value[1]);self.logline(value[1])
                elif kind=='done':
                    out,report=value;self.set_busy(False);self.progress['value']=100
                    self.status.configure(text='转换完成 · 骨骼、无嘴与贴图像素检查通过');self.open_btn.configure(state='normal');self.logline('已完成 VRM 重新导入验证。')
                    if (out/'preview.png').exists():
                        im=Image.open(out/'preview.png').convert('RGBA');im.thumbnail((340,330),Image.Resampling.LANCZOS)
                        bg=Image.new('RGBA',(340,330),FIELD);bg.alpha_composite(im,((340-im.width)//2,(330-im.height)//2))
                        self.photo=ImageTk.PhotoImage(bg);self.canvas.delete('all');self.canvas.create_image(170,165,image=self.photo)
                elif kind=='error':self.set_busy(False);self.status.configure(text=value);self.logline(value);self.open_btn.configure(state='normal' if self.last_output else 'disabled');messagebox.showerror('转换未完成',value)
        except queue.Empty:pass
        self.after(120,self.poll)
    def open_output(self):
        if self.last_output and self.last_output.exists():os.startfile(self.last_output)
    def close(self):
        if self.busy and not messagebox.askyesno('退出','转换正在运行，是否终止转换并退出？'):return
        if self.busy:self.cancel()
        self.destroy()

def main():App().mainloop()
