from pathlib import Path
from datetime import datetime
import json, re, shutil, sys, uuid, subprocess, os
from .skin import read_skin,validate_eyes

def resources():
    return Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))/'resources'

def find_blender():
    candidates=[Path(__file__).resolve().parents[2]/'blender.exe']
    if getattr(sys,'frozen',False):
        candidates += [Path(sys.executable).resolve().parent.parent/'blender.exe',Path(sys.executable).resolve().parent.parent.parent/'blender.exe']
    found=shutil.which('blender')
    if found:candidates.append(Path(found))
    for root in [Path('C:/Program Files/Blender Foundation'),Path('D:/software')]:
        if root.exists():candidates.extend(root.glob('Blender*/blender.exe'));candidates.extend(root.glob('blender*/blender.exe'))
    return str(next((p.resolve() for p in candidates if p.is_file()),''))

def prepare(input_path,output_root,name='',model='auto',height=1.8,eyes=None,opaque_fix=True,preview=True,author='Skin owner'):
    im,info=read_skin(input_path,model,opaque_fix)
    eyes=validate_eyes(eyes)
    if not .5<=float(height)<=3:raise ValueError('模型身高应在 0.5—3 米之间。')
    name=(name or Path(input_path).stem).strip()
    if not name or len(name)>80:raise ValueError('模型名称应为 1—80 个字符。')
    safe=re.sub(r'[<>:"/\\|?*\x00-\x1f]','_',name).strip(' .') or 'Avatar'
    if safe.upper().split('.')[0] in {'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}:safe='Avatar_'+safe
    out=Path(output_root).expanduser().resolve()/(safe+'_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:5])
    out.mkdir(parents=True,exist_ok=False)
    shutil.copy2(input_path,out/'input_skin.png');im.save(out/'prepared_skin.png')
    (out/'pixels.rgba').write_bytes(im.tobytes())
    im.resize((1024,1024),resample=0).save(out/'texture.png')
    job={'schema':1,'name':name,'author':str(author)[:100] or 'Skin owner','output':str(out),'model':info['model'],
         'scale':info['scale'],'height':float(height),'eyes':eyes,'preview':bool(preview),'skin_info':info,'no_mouth':True,
         'addon_root':str(resources()/'addons'),'roundtrip':True}
    (out/'job.json').write_text(json.dumps(job,ensure_ascii=False,indent=2),encoding='utf-8')
    return out,job

def command(blender,out):
    path=Path(blender).expanduser().resolve()
    if not path.is_file() or path.suffix.lower()!='.exe':raise ValueError('请选择 Blender 的 blender.exe。')
    return [str(path),'--background','--factory-startup','--python-exit-code','1','--python',str(resources()/'blender_backend.py'),'--','--job',str(Path(out)/'job.json')]

def run(blender,out,on_progress=lambda p,m:None,cancel=None,on_process=lambda p:None):
    env=os.environ.copy();env['PYTHONIOENCODING']='utf-8'
    # A frozen GUI's DLL directory must not leak into the external Blender.
    frozen_windows=os.name=='nt' and getattr(sys,'frozen',False)
    if frozen_windows:
        import ctypes
        frozen_root=str(Path(sys._MEIPASS).resolve()).lower()
        env['PATH']=os.pathsep.join(p for p in env.get('PATH','').split(os.pathsep)
                                   if not str(Path(p).resolve()).lower().startswith(frozen_root))
    kwargs={'creationflags':subprocess.CREATE_NO_WINDOW} if os.name=='nt' else {}
    with (Path(out)/'conversion.log').open('w',encoding='utf-8') as log:
        if frozen_windows:ctypes.windll.kernel32.SetDllDirectoryW(None)
        try:proc=subprocess.Popen(command(blender,out),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,encoding='utf-8',errors='replace',env=env,**kwargs)
        finally:
            if frozen_windows:ctypes.windll.kernel32.SetDllDirectoryW(sys._MEIPASS)
        on_process(proc)
        for line in proc.stdout:
            log.write(line);log.flush()
            if line.startswith('MCVRM_PROGRESS '):
                try:
                    d=json.loads(line[len('MCVRM_PROGRESS '):]);on_progress(d['percent'],d['message'])
                except (ValueError,KeyError):pass
            if cancel is not None and cancel.is_set() and proc.poll() is None:proc.terminate()
        code=proc.wait()
        proc.stdout.close()
    if cancel is not None and cancel.is_set():raise InterruptedError('转换已取消；源皮肤未修改。')
    report=Path(out)/'report.json'
    if code or not report.exists():
        status=Path(out)/'status.json'
        message=json.loads(status.read_text(encoding='utf-8')).get('error') if status.exists() else None
        raise RuntimeError(message or 'Blender 转换失败，请查看输出目录中的 conversion.log。')
    from .validation import inspect_vrm
    job=json.loads((Path(out)/'job.json').read_text(encoding='utf-8'))
    checks=inspect_vrm(Path(out)/'Avatar.vrm',texture=Path(out)/'texture.png',eyes=job['eyes'])
    result=json.loads(report.read_text(encoding='utf-8'));result.update(checks)
    report.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result
