"""Local Minecraft skin to VRM converter."""
__version__ = '1.1.0'
