"""Blender 5.2 worker. All image preparation happens in the desktop application.
No Pillow or user-specific Python installation is required inside Blender.
"""
from pathlib import Path
import bpy,addon_utils,sys,json,math,os,traceback
from mathutils import Vector,Quaternion
args=sys.argv[sys.argv.index('--')+1:]
job_path=Path(args[args.index('--job')+1]).resolve()
JOB=json.loads(job_path.read_text(encoding='utf-8'))
BASE=job_path.parent
PREVIEW=BASE
def progress(percent,message):
    print('MCVRM_PROGRESS '+json.dumps({'percent':percent,'message':message},ensure_ascii=True),flush=True)
if bpy.app.version[:2]!=(5,2):raise RuntimeError('此版本工具已针对 Blender 5.2 验证，请选择 Blender 5.2。')
sys.path.insert(0,str(Path(__file__).resolve().parent))
sys.path.insert(0,JOB['addon_root'])
addon_utils.enable('io_scene_vrm',default_set=True,persistent=True)
if not hasattr(bpy.types.Armature,'vrm_addon_extension'):raise RuntimeError('VRM 插件未能加载，请查看日志。')
from io_scene_vrm.editor.vrm0.property_group import Vrm0HumanoidPropertyGroup
from validate_vrm import inspect_vrm
F=JOB['scale'];S=JOB['height']/32
ARM_W=3 if JOB['model']=='slim' else 4
ARM_CENTER=4+ARM_W/2
class Pixels:
    def __init__(self):self.data=(BASE/'pixels.rgba').read_bytes()
    def getpixel(self,p):
        x,y=map(int,p);n=(y*(64*F)+x)*4
        return tuple(self.data[n:n+4])
SKIN=Pixels()
EYES=set();EYE_TAGS={};LID_POINTS={}
if JOB['eyes']:
    allcells={tuple(p) for side in ['left','right'] for p in JOB['eyes'][side]}
    for side in ['left','right']:
        cells=JOB['eyes'][side]
        lid=JOB['eyes'].get(side+'_lid')
        if lid is None:
            target=(sum(x for x,y in cells)/len(cells),min(y for x,y in cells)-1)
            available=[(x,y) for y in range(8) for x in range(8) if (x,y) not in allcells]
            lid=min(available,key=lambda p:abs(p[0]-target[0])+1.5*abs(p[1]-target[1]))
        LID_POINTS[side]=((8+lid[0])*F,(8+lid[1])*F)
        for x,y in cells:
            for dy in range(F):
                for dx in range(F):
                    p=((8+x)*F+dx,(8+y)*F+dy);EYES.add(p);EYE_TAGS[p]='eyeL' if side=='left' else 'eyeR'
MESHES=[];RIG=None
def reset():
    global MESHES
    # Data removal also handles unselectable factory/startup objects in 5.2.
    for ob in list(bpy.data.objects):
        bpy.data.objects.remove(ob,do_unlink=True)
    for block in list(bpy.data.meshes):
        if not block.users: bpy.data.meshes.remove(block)
    MESHES=[]

def texture_material(name,double=False,alpha=False):
    mat=bpy.data.materials.new(name)
    mat.vrm_addon_extension.mtoon1.enabled=True
    g=mat.vrm_addon_extension.mtoon1
    g.pbr_metallic_roughness.base_color_factor=(1,1,1,1)
    tex=g.pbr_metallic_roughness.base_color_texture
    tex.index.source=TEX
    tex.index.sampler.mag_filter='NEAREST'
    tex.index.sampler.min_filter='NEAREST'
    tex.index.sampler.wrap_s='CLAMP_TO_EDGE'
    tex.index.sampler.wrap_t='CLAMP_TO_EDGE'
    g.alpha_mode='BLEND' if alpha else 'OPAQUE'
    g.double_sided=double
    m=g.extensions.vrmc_materials_mtoon
    m.shade_color_factor=(0.78,0.81,0.86)
    m.shade_multiply_texture.index.source=TEX
    m.shade_multiply_texture.index.sampler.mag_filter='NEAREST'
    m.shade_multiply_texture.index.sampler.min_filter='NEAREST'
    m.shading_toony_factor=0.85
    m.shading_shift_factor=0.0
    m.gi_equalization_factor=0.8
    m.outline_width_mode='none'
    return mat

def mix(a,b,t):
    t=max(0,min(1,t))
    return {a:1-t,b:t}

def weights(part,p):
    x,y,z=p
    if part=='head': return {'head':1}
    if part=='body':
        if z<15: return mix('hips','spine',(z-12)/3)
        return mix('spine','chest',(z-17)/3)
    side='left' if part.startswith('left') else 'right'
    if part.endswith('Arm'):
        q=abs(x)
        if q<ARM_CENTER+5.5: return mix(side+'UpperArm',side+'LowerArm',(q-ARM_CENTER-3.5)/1)
        return mix(side+'LowerArm',side+'Hand',(q-ARM_CENTER-7.5)/1)
    if z<3: return mix(side+'Foot',side+'LowerLeg',(z-1.5)/1)
    return mix(side+'LowerLeg',side+'UpperLeg',(z-5.5)/1)

class Builder:
    def __init__(self,name,part,material):
        self.name=name; self.part=part; self.mat=material
        self.verts=[]; self.faces=[]; self.uvs=[]; self.tags=[]
    def polygon(self,points,uvs,tag=''):
        first=len(self.verts)
        self.verts.extend(tuple(c*S for c in p) for p in points)
        self.faces.append(tuple(range(first,first+len(points))))
        self.uvs.extend(uvs);self.tags.extend([tag]*len(points))
    def tile(self,points,px,py,tag=''):
        # Pixel centers are constant across each original pixel. This is exact,
        # independent of a receiving application's texture filtering defaults.
        self.polygon(points,[( (px+.5)/(64*F),1-(py+.5)/(64*F))]*len(points),tag)
    def finish(self):
        if not self.verts: return None
        mesh=bpy.data.meshes.new(self.name+'_Mesh')
        mesh.from_pydata(self.verts,[],self.faces);mesh.update()
        ob=bpy.data.objects.new(self.name,mesh)
        bpy.context.scene.collection.objects.link(ob)
        mesh.materials.append(self.mat)
        uv=mesh.uv_layers.new(name='Minecraft_64_PixelCenters')
        for poly in mesh.polygons:
            for li in poly.loop_indices:
                uv.data[li].uv=self.uvs[mesh.loops[li].vertex_index]
        groups={}
        for i,p in enumerate(self.verts):
            for name,w in weights(self.part,tuple(c/S for c in p)).items():
                if w<=0: continue
                if name not in groups: groups[name]=ob.vertex_groups.new(name=name)
                groups[name].add([i],w,'REPLACE')
        ob.parent=RIG
        mod=ob.modifiers.new('Humanoid Skin','ARMATURE');mod.object=RIG
        ob['source_skin']='skin_original.png'
        ob['pixel_mapping']='Minecraft '+JOB['model']+'; nearest pixel centers'
        MESHES.append(ob)
        return ob

def transform_arm(p,part):
    x,y,z=p
    if part=='leftArm': return (ARM_CENTER+22-z,y,22+x-ARM_CENTER)
    if part=='rightArm': return (-ARM_CENTER+z-22,y,22-x-ARM_CENTER)
    return p

def box(part,name,center,dims,origin,inflation,live):
    w,h,d=dims;cx,cy,cz=center;u,v=origin
    xa=cx-w/2-inflation;xb=cx+w/2+inflation
    ya=cy-d/2-inflation;yb=cy+d/2+inflation
    za=cz-h/2-inflation;zb=cz+h/2+inflation
    faces={
      'front':((u+d,v+d,w,h),lambda a,b:(xa+a*(xb-xa),ya,zb-b*(zb-za))),
      'right':((u,v+d,d,h),lambda a,b:(xa,yb-a*(yb-ya),zb-b*(zb-za))),
      'left':((u+d+w,v+d,d,h),lambda a,b:(xb,ya+a*(yb-ya),zb-b*(zb-za))),
      'back':((u+2*d+w,v+d,w,h),lambda a,b:(xb-a*(xb-xa),yb,zb-b*(zb-za))),
      'top':((u+d,v,w,d),lambda a,b:(xa+a*(xb-xa),yb-b*(yb-ya),zb)),
      'bottom':((u+d+w,v,w,d),lambda a,b:(xa+a*(xb-xa),ya+b*(yb-ya),za))}
    builder=Builder(name,part,OUTER if inflation else BASEMAT)
    faint=Builder(name+'_AlphaDetail',part,ALPHAMAT)
    for face,((tx,ty,tw,th),fn) in faces.items():
        for j in range(th*F):
            for i in range(tw*F):
                px,py=tx*F+i,ty*F+j
                alpha=SKIN.getpixel((px,py))[3]
                if alpha==0: continue
                if live and part=='head' and inflation==0 and face=='front' and (px,py) in EYES: continue
                p=[fn(i/(tw*F),j/(th*F)),fn(i/(tw*F),(j+1)/(th*F)),fn((i+1)/(tw*F),(j+1)/(th*F)),fn((i+1)/(tw*F),j/(th*F))]
                (builder if alpha==255 else faint).tile([transform_arm(q,part) for q in p],px,py)
    faint.finish()
    return builder.finish()

def add_compat_fingers(ad):
    """LiveHime's XK ModelMgr requires fingers on both hands, even for block hands.
    These unweighted bones stay inside the palm; they do not change its geometry.
    Caller must be in Edit mode.
    """
    for side,sgn in [('left',1),('right',-1)]:
        for finger,y in [('Thumb',-1.45),('Index',-1.2),('Middle',-.4),('Ring',.4),('Little',1.2)]:
            z=21.45 if finger=='Thumb' else 22.0
            start=ARM_CENTER+8.55 if finger=='Thumb' else ARM_CENTER+9
            step=.32 if finger=='Thumb' else .25
            parent=ad.edit_bones[side+'Hand']
            for n,segment in enumerate(['Proximal','Intermediate','Distal','Tip']):
                name=side+finger+segment
                bone=ad.edit_bones.get(name) or ad.edit_bones.new(name)
                bone.head=Vector((sgn*(start+n*step),y,z))*S
                bone.tail=Vector((sgn*(start+(n+1)*step),y,z))*S
                bone.parent=parent
                bone.use_deform=False
                parent=bone

def rig():
    global RIG
    ad=bpy.data.armatures.new('Avatar_Humanoid')
    RIG=bpy.data.objects.new('Avatar_Humanoid',ad)
    bpy.context.scene.collection.objects.link(RIG)
    bpy.context.view_layer.objects.active=RIG;RIG.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT')
    def bone(name,head,tail,parent=None):
        b=ad.edit_bones.new(name);b.head=Vector(head)*S;b.tail=Vector(tail)*S
        if parent:b.parent=ad.edit_bones[parent]
        b.use_deform=True
        return b
    bone('hips',(0,0,12),(0,0,14))
    bone('spine',(0,0,14),(0,0,18),'hips')
    bone('chest',(0,0,18),(0,0,22),'spine')
    bone('neck',(0,0,22),(0,0,24),'chest')
    bone('head',(0,0,24),(0,0,31),'neck')
    for side,sgn in [('left',1),('right',-1)]:
        bone(side+'Shoulder',(sgn*2.5,0,22),(sgn*ARM_CENTER,0,22),'chest')
        bone(side+'UpperArm',(sgn*ARM_CENTER,0,22),(sgn*(ARM_CENTER+4),0,22),side+'Shoulder')
        bone(side+'LowerArm',(sgn*(ARM_CENTER+4),0,22),(sgn*(ARM_CENTER+8),0,22),side+'UpperArm')
        bone(side+'Hand',(sgn*(ARM_CENTER+8),0,22),(sgn*(ARM_CENTER+10),0,22),side+'LowerArm')
        bone(side+'UpperLeg',(sgn*2,0,12),(sgn*2,0,6),'hips')
        bone(side+'LowerLeg',(sgn*2,0,6),(sgn*2,0,2),side+'UpperLeg')
        bone(side+'Foot',(sgn*2,0,2),(sgn*2,-2,1),side+'LowerLeg')
        bone(side+'Toes',(sgn*2,-1.5,1),(sgn*2,-2.0,1),side+'Foot')
    add_compat_fingers(ad)
    bpy.ops.object.mode_set(mode='OBJECT')
    RIG.show_in_front=True;ad.display_type='OCTAHEDRAL'
    ext=ad.vrm_addon_extension;ext.spec_version='0.0'
    Vrm0HumanoidPropertyGroup.fixup_human_bones(RIG)
    for h in ext.vrm0.humanoid.human_bones:
        if h.bone in ad.bones:h.node.bone_name=h.bone
    fp=ext.vrm0.first_person
    fp.first_person_bone.bone_name='head'
    fp.first_person_bone_offset=(0,-2*S,2*S)
    fp.look_at_type_name='BlendShape'
    for n in ['look_at_horizontal_inner','look_at_horizontal_outer','look_at_vertical_down','look_at_vertical_up']:
        getattr(fp,n).x_range=60;getattr(fp,n).y_range=1
    meta=ext.vrm0.meta
    meta.title=JOB['name']
    meta.version='MCSkinVRM 1.1.0'
    meta.author=JOB['author']
    meta.reference='User supplied Minecraft skin'
    meta.allowed_user_name='ExplicitlyLicensedPerson'
    meta.commercial_ussage_name='Allow'
    meta.license_name='Redistribution_Prohibited'
    RIG['height_m']=JOB['height'];RIG['skin_model']=JOB['model']
    RIG['instructions']='VRM export rest pose: T. Preview pose is stored separately in the scene.'
    return RIG

def face_features():
    bg=Builder('Face_Eye_Backings','head',BASEMAT)
    b=Builder('Face_Tracking','head',BASEMAT)
    for px,py in sorted(EYES):
        x=px/F-12;z=40-py/F;tag=EYE_TAGS[(px,py)]
        side='left' if tag=='eyeL' else 'right'
        sample=LID_POINTS[side]
        def quad(y):return [(x,y,z),(x,y,z-1/F),(x+1/F,y,z-1/F),(x+1/F,y,z)]
        bg.tile(quad(-4),*sample)
        b.tile(quad(-4.004),px,py,tag)
    bg.finish();ob=b.finish()
    if ob is None:raise ValueError('选择的眼睛没有可见像素。')
    ob.shape_key_add(name='Basis')
    groups={tag:[i for i,t in enumerate(b.tags) if t==tag] for tag in ['eyeL','eyeR']}
    presets={'Blink':'blink','Blink_L':'blink_l','Blink_R':'blink_r','Joy':'joy','Angry':'angry','Sorrow':'sorrow','Fun':'fun','LookUp':'lookup','LookDown':'lookdown','LookLeft':'lookleft','LookRight':'lookright'}
    for name,preset in presets.items():
        key=ob.shape_key_add(name=name)
        for tag,ids in groups.items():
            if not ids:raise ValueError('每只眼睛都需要选择可见像素。')
            points=[Vector(b.verts[i])/S for i in ids]
            cx=(min(p.x for p in points)+max(p.x for p in points))/2
            cz=(min(p.z for p in points)+max(p.z for p in points))/2
            width=max(p.x for p in points)-min(p.x for p in points)
            height=max(p.z for p in points)-min(p.z for p in points)
            side=1 if tag=='eyeL' else -1
            for i in ids:
                p=Vector(b.verts[i])/S
                if name=='Blink' or (name=='Blink_L' and tag=='eyeL') or (name=='Blink_R' and tag=='eyeR'):p.z=cz+(p.z-cz)*.07
                elif name in ['Joy','Fun']:p.z=cz+height*.08+(p.z-cz)*(.85 if name=='Joy' else .9)
                elif name=='Angry':p.z+=(p.x-cx)*side*.16
                elif name=='Sorrow':p.z-=(p.x-cx)*side*.12
                elif name=='LookUp':p.z+=height*.10
                elif name=='LookDown':p.z-=height*.10
                elif name=='LookLeft':p.x+=width*.08
                elif name=='LookRight':p.x-=width*.08
                p.x=max(-4,min(4,p.x));p.z=max(24,min(32,p.z))
                key.data[i].co=p*S
        group=RIG.data.vrm_addon_extension.vrm0.blend_shape_master.blend_shape_groups.add()
        group.name=name;group.preset_name=preset
        binding=group.binds.add();binding.mesh.mesh_object_name=ob.name;binding.index=name;binding.weight=1
    neutral=RIG.data.vrm_addon_extension.vrm0.blend_shape_master.blend_shape_groups.add()
    neutral.name='Neutral';neutral.preset_name='neutral'
    ob['no_mouth']=True
    return ob


def build(live):
    global TEX,BASEMAT,OUTER,ALPHAMAT
    reset();rig()
    TEX=bpy.data.images.load(str(BASE/'texture.png'),check_existing=True)
    TEX.name='MC_OriginalPixels_1024_Nearest';TEX.pack()
    BASEMAT=texture_material('MC_Pixel_MToon')
    OUTER=texture_material('MC_OuterLayer_MToon',True)
    ALPHAMAT=texture_material('MC_FaintAlpha_MToon',True,True)
    parts=[
      ('head',(0,0,28),(8,8,8),(0,0),(32,0)),
      ('body',(0,0,18),(8,12,4),(16,16),(16,32)),
      ('rightArm',(-ARM_CENTER,0,18),(ARM_W,12,4),(40,16),(40,32)),
      ('leftArm',(ARM_CENTER,0,18),(ARM_W,12,4),(32,48),(48,48)),
      ('rightLeg',(-2,0,6),(4,12,4),(0,16),(0,32)),
      ('leftLeg',(2,0,6),(4,12,4),(16,48),(0,48))]
    for part,center,dims,uv,outer in parts:
        box(part,part+'_Base',center,dims,uv,0,live)
        box(part,part+'_Overlay',center,dims,outer,.5 if part=='head' else .25,live)
    if live:face_features()
    for ob in MESHES:
        a=RIG.data.vrm_addon_extension.vrm0.first_person.mesh_annotations.add()
        a.mesh.mesh_object_name=ob.name
        a.first_person_flag='ThirdPersonOnly' if ob.name.startswith(('head','Face')) else 'Both'
    bpy.context.view_layer.update()
    unexpected=[o.name for o in bpy.data.objects if o.type=='MESH' and o not in MESHES]
    if unexpected:raise ValueError('场景包含非角色网格：'+', '.join(unexpected))

def select_avatar():
    bpy.ops.object.select_all(action='DESELECT')
    for ob in MESHES+[RIG]: ob.select_set(True)
    bpy.context.view_layer.objects.active=RIG

def export(name):
    select_avatar()
    result=bpy.ops.export_scene.vrm(filepath=str(BASE/name),armature_object_name=RIG.name,export_only_selections=True,export_invisibles=False)
    print('EXPORT_RESULT',name,result,flush=True)
    if result!={'FINISHED'}:raise RuntimeError('VRM export failed')

def world_rotate(bone,axis,angle):
    pb=RIG.pose.bones[bone];q=pb.bone.matrix_local.to_quaternion()
    pb.rotation_mode='QUATERNION'
    pb.rotation_quaternion=q.inverted() @ Quaternion(axis,math.radians(angle)) @ q

def pose(relaxed=True):
    for b in RIG.pose.bones:
        b.rotation_mode='QUATERNION';b.rotation_quaternion=(1,0,0,0)
    if relaxed:
        world_rotate('leftUpperArm',(0,1,0),90)
        world_rotate('rightUpperArm',(0,1,0),-90)
    bpy.context.view_layer.update()

def point(ob,at):
    ob.rotation_euler=(Vector(at)-ob.location).to_track_quat('-Z','Y').to_euler()

def studio():
    scene=bpy.context.scene
    scene.render.engine='CYCLES';scene.cycles.samples=32
    scene.cycles.use_denoising=True
    scene.render.resolution_x=800;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
    scene.render.image_settings.file_format='PNG';scene.render.film_transparent=True
    scene.view_settings.view_transform='Standard'
    scene.world.color=(.45,.45,.45)
    for name,loc,power,size in [('Key',(-3,-4,5),450,4),('Fill',(4,-2,3),250,3),('Rim',(2,3,4),500,3)]:
        data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size
        ob=bpy.data.objects.new(name,data);scene.collection.objects.link(ob);ob.location=loc;point(ob,(0,0,1))
    data=bpy.data.cameras.new('Avatar_Preview');cam=bpy.data.objects.new('Avatar_Preview',data)
    scene.collection.objects.link(cam);scene.camera=cam;data.type='ORTHO';data.ortho_scale=2.12
    cam.location=(2.7,-5,2.5);point(cam,(0,0,.91))
    return cam

def render(name,loc,target,scale):
    cam=bpy.context.scene.camera;cam.location=loc;point(cam,target);cam.data.ortho_scale=scale
    bpy.context.scene.render.filepath=str(PREVIEW/name)
    bpy.ops.render.render(write_still=True)
    print('RENDERED',name,flush=True)


def main():
    progress(10,'构建像素网格与双层皮肤')
    build(bool(JOB['eyes']))
    progress(42,'检查 51 项人形映射和双手手指')
    mapped={h.bone:h.node.bone_name for h in RIG.data.vrm_addon_extension.vrm0.humanoid.human_bones if h.node.bone_name}
    if len(mapped)!=51:raise ValueError('人形骨骼映射不完整。')
    preview_files=[]
    if JOB['preview']:
        progress(50,'渲染预览图')
        pose(True);studio()
        scene=bpy.context.scene;scene.cycles.device='CPU';scene.cycles.samples=16
        scene.render.resolution_x=512;scene.render.resolution_y=640
        scene.render.image_settings.media_type='IMAGE'
        render('preview.png',(2.6,-6,2.5),(0,0,.91*S/(1.8/32)),2.16*S/(1.8/32))
        # Cameras and framing scale with avatar height.
        preview_files.append('preview.png')
        thumb=bpy.data.images.load(str(BASE/'preview.png'));thumb.pack()
        RIG.data.vrm_addon_extension.vrm0.meta.texture=thumb
    pose(False)
    progress(65,'导出 VRM 0.x')
    export('Avatar.vrm')
    checks=inspect_vrm(BASE/'Avatar.vrm',eyes=JOB['eyes'])
    progress(78,'打包可编辑 Blender 工程')
    pose(True)
    for ng in list(bpy.data.node_groups):
        if ng.library:ng.make_local()
    for image in bpy.data.images:
        if image.type=='IMAGE' and image.has_data:image.pack()
    bpy.context.scene.unit_settings.system='METRIC'
    bpy.context.scene['MCSkinVRM']='No added mouth. Rest pose is T. Compatibility fingers preserve block hands.'
    select_avatar();RIG.show_in_front=False
    bpy.ops.file.pack_all()
    bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'Avatar.blend'))
    if JOB['roundtrip']:
        progress(88,'重新导入验证 VRM')
        for ob in list(bpy.data.objects):bpy.data.objects.remove(ob,do_unlink=True)
        os.environ['BLENDER_VRM_AUTOMATIC_LICENSE_CONFIRMATION']='true'
        result=bpy.ops.import_scene.vrm(filepath=str(BASE/'Avatar.vrm'),extract_textures_into_folder=False)
        if result!={'FINISHED'}:raise ValueError('导出的 VRM 无法重新导入。')
        rig=next(o for o in bpy.data.objects if o.type=='ARMATURE')
        mapped={h.bone:h.node.bone_name for h in rig.data.vrm_addon_extension.vrm0.humanoid.human_bones if h.node.bone_name}
        if len(mapped)!=51:raise ValueError('重新导入后骨骼映射丢失。')
        shapes={k.name for o in bpy.data.objects if o.type=='MESH' and o.data.shape_keys for k in o.data.shape_keys.key_blocks}
        if JOB['eyes'] and not {'Blink','Blink_L','Blink_R'}<=shapes:raise ValueError('重新导入后眨眼形态键丢失。')
        if {'A','I','U','E','O','Mouth','JawOpen'}&shapes:raise ValueError('意外检测到口型。')
        checks['roundtrip_import']=True
    checks.update({'converter_version':'1.1.0','name':JOB['name'],'skin':JOB['skin_info'],'height_m':JOB['height'],'preview_files':preview_files,'outputs':['Avatar.vrm','Avatar.blend','prepared_skin.png','texture.png','report.json']})
    (BASE/'report.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
    (BASE/'status.json').write_text(json.dumps({'success':True}),encoding='utf-8')
    progress(100,'转换完成')

if __name__=='__main__':
    try:main()
    except Exception as error:
        (BASE/'status.json').write_text(json.dumps({'success':False,'error':str(error)},ensure_ascii=False),encoding='utf-8')
        traceback.print_exc();sys.exit(1)
