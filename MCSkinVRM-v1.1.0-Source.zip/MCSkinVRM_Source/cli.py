import argparse,json,sys
from mcvrm.jobs import find_blender,prepare,run
def main():
    p=argparse.ArgumentParser(description='Convert Minecraft skin PNGs to mouthless VRM 0 avatars locally.')
    p.add_argument('skin');p.add_argument('--output',required=True);p.add_argument('--blender',default=find_blender())
    p.add_argument('--name',default='');p.add_argument('--author',default='Skin owner');p.add_argument('--model',choices=['auto','classic','slim'],default='auto')
    p.add_argument('--height',type=float,default=1.8);p.add_argument('--eyes',help='Optional eye pixel profile JSON')
    p.add_argument('--keep-opaque-overlay',action='store_true');p.add_argument('--no-preview',action='store_true')
    a=p.parse_args()
    eyes=json.load(open(a.eyes,encoding='utf-8-sig')) if a.eyes else None
    out,job=prepare(a.skin,a.output,a.name,a.model,a.height,eyes,not a.keep_opaque_overlay,not a.no_preview,a.author)
    print('OUTPUT',str(out),flush=True)
    report=run(a.blender,out,lambda p,m:print(f'{p:3d}% {m}',flush=True))
    print(json.dumps(report,ensure_ascii=True,indent=2))
if __name__=='__main__':
    try:main()
    except Exception as e:print('ERROR:',str(e),file=sys.stderr);sys.exit(1)
