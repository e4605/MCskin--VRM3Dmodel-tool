"""Run with the developer's Python and PyInstaller installed; creates a portable folder."""
from pathlib import Path
import subprocess,sys,os,shutil
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parent
icon=Image.new('RGBA',(256,256),(12,20,35,255));d=ImageDraw.Draw(icon)
d.polygon([(128,38),(220,88),(128,139),(36,88)],fill='#86e8ca')
d.polygon([(36,88),(128,139),(128,230),(36,178)],fill='#2a937b')
d.polygon([(128,139),(220,88),(220,178),(128,230)],fill='#52c6aa')
d.line([(128,38),(128,139),(128,230)],fill='#c9ffef',width=4)
icon.save(ROOT/'resources/app.ico',sizes=[(16,16),(32,32),(48,48),(128,128),(256,256)])
env=os.environ.copy();env['PYTHONPATH']=str(ROOT/'build_deps')+os.pathsep+str(ROOT)
args=[sys.executable,'-m','PyInstaller','--noconfirm','--clean','--windowed','--name','MCSkinVRM',
      '--icon',str(ROOT/'resources/app.ico'),'--add-data',str(ROOT/'resources')+os.pathsep+'resources',
      '--paths',str(ROOT),'--exclude-module','numpy','--exclude-module','matplotlib','--exclude-module','bpy',str(ROOT/'app.py')]
subprocess.run(args,cwd=ROOT,env=env,check=True)
target=ROOT/'dist/MCSkinVRM'
for filename in ['使用说明.md','研究与兼容性.md','THIRD_PARTY_NOTICES.md','LICENSE']:
    if (ROOT/filename).exists():shutil.copy2(ROOT/filename,target/filename)
if (ROOT/'licenses').exists():shutil.copytree(ROOT/'licenses',target/'licenses',dirs_exist_ok=True)
print('PORTABLE_BUILD_READY',target,flush=True)
