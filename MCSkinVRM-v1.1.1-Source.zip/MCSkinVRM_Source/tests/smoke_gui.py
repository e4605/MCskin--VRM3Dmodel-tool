"""Application-level smoke check without sending any desktop input."""
from pathlib import Path
from types import SimpleNamespace
import sys,json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import mcvrm.gui as gui
gui.SETTINGS=ROOT/'test_outputs/ui_smoke_settings.json'
app=gui.App();app.withdraw();app.demo();app.detect_blender()
assert Path(app.blender.get()).name.lower()=='blender.exe'
editor=gui.EyeEditor(app,app.normalized,None,lambda p:(setattr(app,'eye_profile',p),app.eyes.set(True)))
editor.withdraw();editor.example()
assert len(editor.profile['left'])==len(editor.profile['right'])==5
editor.click(SimpleNamespace(x=5*48+24,y=5*48+24))
assert len(editor.profile['left'])==4
editor.click(SimpleNamespace(x=5*48+24,y=5*48+24))
assert len(editor.profile['left'])==5
editor.accept();assert app.eyes.get() and len(app.eye_profile['left'])==5
app.update_idletasks()
assert 'TickIndicator' in app.tk.call('ttk::style','element','names')
app.output.set(str(ROOT/'test_outputs'));app.name.set('UI_v1_1');app.start()
def done():
    if app.busy:app.after(200,done);return
    report=json.loads((app.last_output/'report.json').read_text(encoding='utf-8'))
    assert report['texture_pixels_verified'] and report['roundtrip_import']
    assert report['converter_version']=='1.1.1'
    assert 'Blink' in report['shape_keys']
    (ROOT/'gui_smoke_result.json').write_text(json.dumps({'output':str(app.last_output),'eye_toggle':True,'eye_apply':True,'automatic_blender':True,'check_indicator':True,'roundtrip':True},indent=2),encoding='utf-8')
    print('GUI_FLOW_SMOKE_PASSED',flush=True);app.destroy()
app.after(200,done)
app.after(90000,lambda:(_ for _ in ()).throw(TimeoutError('GUI smoke timeout')))
app.mainloop()
