import unittest,tempfile,json,shutil
from pathlib import Path
from unittest.mock import patch
from PIL import UnidentifiedImageError
from test_skin import fixture
from mcvrm.jobs import prepare,prepare_with_fallback,OutputDirectoryError

class OutputPermissionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.skin=self.root/'skin.png';fixture(self.skin)
        self.blocked=self.root/'blocked_desktop';self.safe=self.root/'user_exports'
        self.mkdir=Path.mkdir
    def tearDown(self):self.temp.cleanup()
    def deny_mkdir(self,path,*args,**kwargs):
        if path.is_relative_to(self.blocked):raise PermissionError(13,'Access denied',str(path))
        return self.mkdir(path,*args,**kwargs)
    def test_mkdir_denied_recovers_and_job_points_to_actual_destination(self):
        original=self.skin.read_bytes()
        with patch.object(Path,'mkdir',lambda path,*a,**k:self.deny_mkdir(path,*a,**k)),patch('mcvrm.jobs.recommended_output_dirs',return_value=[self.safe]):
            out,job,notice=prepare_with_fallback(self.skin,self.blocked)
        self.assertEqual(out.parent,self.safe);self.assertIn(str(self.safe),notice)
        self.assertEqual(json.loads((out/'job.json').read_text(encoding='utf-8'))['output'],str(out))
        self.assertEqual((out/'input_skin.png').read_bytes(),original)
        self.assertEqual(self.skin.read_bytes(),original)
    def test_write_denied_after_mkdir_also_recovers(self):
        copy=shutil.copy2
        def guarded(src,dst,*a,**k):
            if Path(dst).is_relative_to(self.blocked):raise PermissionError(13,'Access denied',str(dst))
            return copy(src,dst,*a,**k)
        with patch('mcvrm.jobs.shutil.copy2',side_effect=guarded),patch('mcvrm.jobs.recommended_output_dirs',return_value=[self.safe]):
            out,_,notice=prepare_with_fallback(self.skin,self.blocked)
        self.assertTrue((out/'texture.png').exists());self.assertTrue(notice)
    def test_all_destinations_denied_has_actionable_error(self):
        with patch.object(Path,'mkdir',side_effect=PermissionError(13,'Access denied')),patch('mcvrm.jobs.recommended_output_dirs',return_value=[self.safe]):
            with self.assertRaisesRegex(OutputDirectoryError,'推荐目录'):
                prepare_with_fallback(self.skin,self.blocked)
    def test_invalid_skin_does_not_trigger_fallback(self):
        bad=self.root/'bad.png';bad.write_bytes(b'invalid PNG')
        with patch('mcvrm.jobs.recommended_output_dirs') as candidates:
            with self.assertRaises(UnidentifiedImageError):prepare_with_fallback(bad,self.blocked)
        candidates.assert_not_called()
    def test_cli_prepare_reports_output_permission_without_redirecting(self):
        with patch.object(Path,'mkdir',lambda path,*a,**k:self.deny_mkdir(path,*a,**k)):
            with self.assertRaises(OutputDirectoryError):prepare(self.skin,self.blocked)
        self.assertFalse(self.safe.exists())

if __name__=='__main__':unittest.main()
